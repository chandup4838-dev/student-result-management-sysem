<?php
/* register.php - a student creates their own account */
require_once 'includes/auth.php';

if (isStudent()) redirect('dashboard.php');

$error = '';
$departments = ['Computer Science & Engineering', 'AI & Data Science',
                'Electronics & Communication', 'Electrical & Electronics'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $student_id = trim($_POST['student_id'] ?? '');
    $name       = trim($_POST['name'] ?? '');
    $email      = trim($_POST['email'] ?? '');
    $phone      = trim($_POST['phone'] ?? '');
    $department = $_POST['department'] ?? '';
    $year       = (int)($_POST['year'] ?? 1);
    $semester   = (int)($_POST['semester'] ?? 1);
    $password   = $_POST['password'] ?? '';
    $confirm    = $_POST['confirm'] ?? '';

    if ($student_id === '' || $name === '' || $email === '' || $password === '') {
        $error = 'Fill in every required field.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'That email address is not valid.';
    } elseif (strlen($password) < 6) {
        $error = 'Use a password of at least 6 characters.';
    } elseif ($password !== $confirm) {
        $error = 'The two passwords do not match.';
    } else {
        $check = $pdo->prepare("SELECT COUNT(*) FROM users WHERE student_id = ? OR email = ?");
        $check->execute([$student_id, $email]);
        if ($check->fetchColumn() > 0) {
            $error = 'That roll number or email is already registered.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);   // bcrypt hash
            $ins = $pdo->prepare(
                "INSERT INTO users (student_id, name, email, phone, department, year, semester, password)
                 VALUES (?,?,?,?,?,?,?,?)"
            );
            $ins->execute([$student_id, $name, $email, $phone, $department, $year, $semester, $hash]);
            set_flash('success', 'Account created. Sign in with your roll number.');
            redirect('login.php');
        }
    }
}

$LAYOUT = 'public';
$PAGE_TITLE = 'Student Registration';
include 'includes/header.php';
?>
<div class="auth-wrap">
  <div class="auth-card" style="width:min(640px,100%)">
    <h2>Create your student account</h2>
    <p class="muted">Your roll number must match the one issued by the examination cell, otherwise your results will not appear.</p>

    <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>

    <form method="post" autocomplete="off">
      <div class="form-row">
        <div class="field"><label for="student_id">Roll number</label>
          <input id="student_id" name="student_id" value="<?= e($_POST['student_id'] ?? '') ?>" required></div>
        <div class="field"><label for="name">Full name</label>
          <input id="name" name="name" value="<?= e($_POST['name'] ?? '') ?>" required></div>
      </div>
      <div class="form-row">
        <div class="field"><label for="email">Email</label>
          <input type="email" id="email" name="email" value="<?= e($_POST['email'] ?? '') ?>" required></div>
        <div class="field"><label for="phone">Phone</label>
          <input id="phone" name="phone" value="<?= e($_POST['phone'] ?? '') ?>"></div>
      </div>
      <div class="field"><label for="department">Department</label>
        <select id="department" name="department" required>
          <?php foreach ($departments as $d): ?>
            <option <?= (($_POST['department'] ?? '') === $d) ? 'selected' : '' ?>><?= e($d) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-row">
        <div class="field"><label for="year">Year</label>
          <select id="year" name="year"><?php for ($i=1;$i<=4;$i++): ?>
            <option value="<?= $i ?>" <?= (($_POST['year'] ?? '')==$i)?'selected':'' ?>>Year <?= $i ?></option>
          <?php endfor; ?></select></div>
        <div class="field"><label for="semester">Current semester</label>
          <select id="semester" name="semester"><?php for ($i=1;$i<=8;$i++): ?>
            <option value="<?= $i ?>" <?= (($_POST['semester'] ?? '')==$i)?'selected':'' ?>>Semester <?= $i ?></option>
          <?php endfor; ?></select></div>
      </div>
      <div class="form-row">
        <div class="field"><label for="password">Password</label>
          <input type="password" id="password" name="password" required></div>
        <div class="field"><label for="confirm">Repeat password</label>
          <input type="password" id="confirm" name="confirm" required></div>
      </div>
      <button class="btn btn-primary btn-block" type="submit">Create account</button>
    </form>

    <p class="tiny muted" style="margin-top:1rem">Already registered? <a href="login.php">Sign in</a></p>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
