<?php
/* logout.php - end the student session */
require_once 'includes/auth.php';
$_SESSION = [];
session_destroy();
session_start();
set_flash('success', 'You have been signed out.');
header('Location: login.php');
exit;
