<?php
/* semesters.php - My Academic Journey */
require_once 'includes/auth.php';
requireStudent();

$student = currentStudent($pdo);
$sid = $student['student_id'];

/* one row per semester, but only where the result has been published */
$q = $pdo->prepare(
    "SELECT sm.* FROM semesters sm
     WHERE sm.student_id = ?
       AND EXISTS (SELECT 1 FROM results r WHERE r.student_id = sm.student_id
                   AND r.semester = sm.semester AND r.status = 'Published')
     ORDER BY sm.semester ASC"
);
$q->execute([$sid]);
$semesters = $q->fetchAll();

$trend = [];
foreach ($semesters as $s) {
    $trend[] = ['sem' => (int)$s['semester'], 'sgpa' => (float)$s['sgpa'], 'cgpa' => (float)$s['cgpa']];
}
$latest = $semesters ? end($semesters) : null;

/* pass / fail status of each semester */
$statusOf = [];
foreach ($semesters as $s) {
    $rows = getResultRows($pdo, $sid, $s['semester']);
    $statusOf[$s['semester']] = summarise($rows);
}

$LAYOUT = 'student'; $ACTIVE = 'semesters'; $PAGE_TITLE = 'My Academic Journey';
include 'includes/header.php';
?>

<?php if (!$semesters): ?>
  <div class="card"><p class="empty">Your academic journey will be built here as each semester result is published.</p></div>
<?php else: ?>

<div class="cards">
  <div class="stat-card gold"><small>Current CGPA</small><b><?= number_format($latest['cgpa'], 2) ?></b>
    <span class="sub">after semester <?= (int)$latest['semester'] ?></span></div>
  <div class="stat-card"><small>Best SGPA</small>
    <b><?= number_format(max(array_column($semesters, 'sgpa')), 2) ?></b><span class="sub">your highest semester</span></div>
  <div class="stat-card"><small>Semesters completed</small><b><?= count($semesters) ?></b>
    <span class="sub">results published</span></div>
</div>

<?php if (count($trend) > 1): ?>
<div class="card">
  <div class="card-head"><h3>Progress across semesters</h3></div>
  <div class="trend" id="cgpaTrend" data-points='<?= json_encode($trend) ?>'></div>
</div>
<?php endif; ?>

<div class="card">
  <div class="card-head"><h3>Semester by semester</h3>
    <span class="tiny muted">Select a semester to open its full marksheet</span></div>
  <div class="journey">
    <?php foreach ($semesters as $s):
        $sum = $statusOf[$s['semester']]; ?>
      <div class="j-item">
        <div class="j-sem">Semester <?= (int)$s['semester'] ?></div>
        <div class="j-metrics">
          <div><b><?= number_format($s['sgpa'], 2) ?></b><small>SGPA</small></div>
          <div><b><?= number_format($s['cgpa'], 2) ?></b><small>CGPA</small></div>
          <div><b><?= number_format($s['percentage'], 2) ?>%</b><small>Percentage</small></div>
          <div><b><?= $sum['passed'] ?>/<?= $sum['subjects'] ?></b><small>Subjects cleared</small></div>
          <div><span class="badge <?= $sum['status'] === 'PASS' ? 'b-pass' : 'b-fail' ?>"><?= $sum['status'] ?></span><small>Result</small></div>
        </div>
        <div class="actions">
          <a class="btn btn-ghost btn-sm" href="result.php?sem=<?= (int)$s['semester'] ?>">Marksheet</a>
          <a class="btn btn-primary btn-sm" href="performance.php?sem=<?= (int)$s['semester'] ?>">Analysis</a>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<div class="card">
  <h3>How the CGPA is built</h3>
  <p class="muted" style="margin:0">
    Each semester gives SGPA = &Sigma;(credit &times; grade point) &divide; &Sigma;credits.
    The CGPA shown against a semester uses the same formula over every subject up to and including
    that semester, so it is a credit-weighted cumulative average rather than a plain average of SGPAs.
  </p>
</div>

<?php endif; ?>
<?php include 'includes/footer.php'; ?>
