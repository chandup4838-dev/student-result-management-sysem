Put your college logo here as logo.png or logo.svg.
logo.svg is a placeholder mark used by the marksheet header.
Student photographs (optional) can be stored here as <rollnumber>.jpg.
