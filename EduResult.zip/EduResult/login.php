<?php
/* login.php - student login */
require_once 'includes/auth.php';

if (isStudent()) redirect('dashboard.php');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $student_id = trim($_POST['student_id'] ?? '');
    $password   = $_POST['password'] ?? '';

    if ($student_id === '' || $password === '') {
        $error = 'Enter your roll number and password.';
    } else {
        /* prepared statement - protects against SQL injection */
        $q = $pdo->prepare("SELECT * FROM users WHERE student_id = ?");
        $q->execute([$student_id]);
        $user = $q->fetch();

        /* password_verify() compares the typed password with the stored hash */
        if ($user && password_verify($password, $user['password'])) {
            session_regenerate_id(true);                 // stops session fixation
            $_SESSION['student_id']   = $user['student_id'];
            $_SESSION['student_name'] = $user['name'];
            redirect('dashboard.php');
        } else {
            $error = 'Roll number or password is incorrect.';
        }
    }
}

$LAYOUT = 'public';
$PAGE_TITLE = 'Student Login';
include 'includes/header.php';
?>
<div class="auth-wrap">
  <div class="auth-card">
    <div class="tabs">
      <a class="active" href="login.php">Student</a>
      <a href="admin/login.php">Admin</a>
    </div>

    <h2>Student login</h2>
    <p class="muted">Use the roll number printed on your college ID card.</p>

    <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>

    <form method="post" autocomplete="off">
      <div class="field">
        <label for="student_id">Roll number / Student ID</label>
        <input type="text" id="student_id" name="student_id" placeholder="CSE2021001"
               value="<?= e($_POST['student_id'] ?? '') ?>" required>
      </div>
      <div class="field">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" placeholder="Your password" required>
      </div>
      <button class="btn btn-primary btn-block" type="submit">Sign in</button>
    </form>

    <div class="demo-box">
      <b>Demo account</b><br>
      Roll number <b>CSE2021001</b> &nbsp;&middot;&nbsp; Password <b>student123</b>
    </div>

    <p class="tiny muted" style="margin-top:1rem">
      New student? <a href="register.php">Create an account</a> &nbsp;&middot;&nbsp;
      <a href="search-result.php">Check a result without logging in</a>
    </p>
  </div>
</div>
<?php include 'includes/footer.php'; ?>
