/* ============================================================
   EduResult - js/script.js
   Plain JavaScript only. No external library is used.
   ============================================================ */

document.addEventListener('DOMContentLoaded', function () {

  /* ---------- 1. Animate the subject performance bars ---------- */
  var bars = document.querySelectorAll('.bar-fill');
  setTimeout(function () {
    bars.forEach(function (bar) {
      var pct = parseFloat(bar.getAttribute('data-width')) || 0;
      bar.style.width = Math.max(0, Math.min(100, pct)) + '%';
    });
  }, 120);

  /* ---------- 2. Draw the SGPA / CGPA trend chart as inline SVG ---------- */
  var trend = document.getElementById('cgpaTrend');
  if (trend) {
    var data = [];
    try { data = JSON.parse(trend.getAttribute('data-points') || '[]'); } catch (err) { data = []; }
    if (data.length) drawTrend(trend, data);
  }

  function drawTrend(box, data) {
    var W = 760, H = 240, padL = 46, padR = 20, padT = 20, padB = 34;
    var maxY = 10, minY = 0;                       // GPA scale 0 - 10
    var innerW = W - padL - padR, innerH = H - padT - padB;
    var stepX = data.length > 1 ? innerW / (data.length - 1) : 0;

    function x(i) { return padL + stepX * i; }
    function y(v) { return padT + innerH - ((v - minY) / (maxY - minY)) * innerH; }

    var svg = '<svg viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="SGPA and CGPA by semester">';

    /* horizontal grid lines + y axis labels */
    for (var g = 0; g <= 10; g += 2) {
      svg += '<line x1="' + padL + '" y1="' + y(g) + '" x2="' + (W - padR) + '" y2="' + y(g) +
             '" stroke="#D9E1EC" stroke-width="1"/>';
      svg += '<text x="' + (padL - 10) + '" y="' + (y(g) + 4) + '" text-anchor="end" font-size="11" fill="#5D6B80">' + g + '</text>';
    }

    /* build the two poly-lines */
    var sgpaPts = '', cgpaPts = '';
    data.forEach(function (d, i) {
      sgpaPts += x(i) + ',' + y(d.sgpa) + ' ';
      cgpaPts += x(i) + ',' + y(d.cgpa) + ' ';
    });
    svg += '<polyline points="' + cgpaPts + '" fill="none" stroke="#B8862B" stroke-width="2.5" stroke-dasharray="6 4"/>';
    svg += '<polyline points="' + sgpaPts + '" fill="none" stroke="#1B3157" stroke-width="3"/>';

    /* dots, values and x labels */
    data.forEach(function (d, i) {
      svg += '<circle cx="' + x(i) + '" cy="' + y(d.sgpa) + '" r="5" fill="#1B3157"/>';
      svg += '<circle cx="' + x(i) + '" cy="' + y(d.cgpa) + '" r="4" fill="#B8862B"/>';
      svg += '<text x="' + x(i) + '" y="' + (y(d.sgpa) - 12) + '" text-anchor="middle" font-size="11" font-weight="600" fill="#0E1A2B">' + d.sgpa.toFixed(2) + '</text>';
      svg += '<text x="' + x(i) + '" y="' + (H - 10) + '" text-anchor="middle" font-size="11" fill="#5D6B80">Sem ' + d.sem + '</text>';
    });

    svg += '</svg>';
    box.innerHTML = svg +
      '<p class="tiny muted" style="margin-top:.4rem">' +
      '<span style="color:#1B3157;font-weight:600">&#9679; SGPA (that semester)</span> &nbsp; ' +
      '<span style="color:#B8862B;font-weight:600">&#9679; CGPA (cumulative)</span></p>';
  }

  /* ---------- 3. Instant table search (admin lists) ---------- */
  document.querySelectorAll('[data-filter]').forEach(function (input) {
    input.addEventListener('keyup', function () {
      var table = document.querySelector(input.getAttribute('data-filter'));
      if (!table) return;
      var term = input.value.toLowerCase();
      table.querySelectorAll('tbody tr').forEach(function (row) {
        row.style.display = row.textContent.toLowerCase().indexOf(term) > -1 ? '' : 'none';
      });
    });
  });

  /* ---------- 4. Live total + grade preview on the marks entry form ---------- */
  var internal = document.getElementById('internal_marks');
  var external = document.getElementById('external_marks');
  var preview  = document.getElementById('gradePreview');

  function grade(total) {
    if (total >= 90) return ['O', 10];
    if (total >= 80) return ['A+', 9];
    if (total >= 70) return ['A', 8];
    if (total >= 60) return ['B+', 7];
    if (total >= 50) return ['B', 6];
    if (total >= 40) return ['C', 5];
    return ['F', 0];
  }

  function updatePreview() {
    if (!preview) return;
    var i = parseInt(internal.value, 10) || 0;
    var x = parseInt(external.value, 10) || 0;
    var total = i + x;
    var g = grade(total);
    preview.innerHTML =
      'Total <b>' + total + '</b> / 100 &nbsp;&middot;&nbsp; Grade <b>' + g[0] + '</b>' +
      ' &nbsp;&middot;&nbsp; Grade point <b>' + g[1] + '</b>' +
      ' &nbsp;&middot;&nbsp; <b style="color:' + (total >= 40 ? '#0E7A52' : '#B3261E') + '">' +
      (total >= 40 ? 'PASS' : 'FAIL') + '</b>';
  }
  if (internal && external && preview) {
    internal.addEventListener('input', updatePreview);
    external.addEventListener('input', updatePreview);
    updatePreview();
  }

  /* ---------- 5. Print / Save as PDF ---------- */
  document.querySelectorAll('[data-print]').forEach(function (btn) {
    btn.addEventListener('click', function () { window.print(); });
  });

  /* the "Download result" button on the dashboard opens result.php?print=1,
     so the print dialog is opened automatically once the marksheet is on screen */
  if (location.search.indexOf('print=1') > -1 && document.querySelector('.marksheet')) {
    setTimeout(function () { window.print(); }, 400);
  }

  /* ---------- 6. Ask before deleting ---------- */
  document.querySelectorAll('.confirm-delete').forEach(function (link) {
    link.addEventListener('click', function (ev) {
      if (!confirm('Delete this record permanently? This cannot be undone.')) ev.preventDefault();
    });
  });

  /* ---------- 7. Count-up for the numbers on the home page ---------- */
  document.querySelectorAll('[data-count]').forEach(function (el) {
    var target = parseFloat(el.getAttribute('data-count'));
    var suffix = el.getAttribute('data-suffix') || '';
    var start = null, dur = 1100;
    function tick(ts) {
      if (!start) start = ts;
      var p = Math.min((ts - start) / dur, 1);
      el.textContent = Math.floor(target * p).toLocaleString() + suffix;
      if (p < 1) requestAnimationFrame(tick);
    }
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      el.textContent = target.toLocaleString() + suffix;
    } else {
      requestAnimationFrame(tick);
    }
  });
});
