<?php
/* admin/semesters.php - stored SGPA / CGPA per student per semester */
require_once '../includes/auth.php';
requireAdmin();

/* recalculate everything (useful after importing the sample data) */
if (($_GET['action'] ?? '') === 'recalc') {
    $ids = $pdo->query("SELECT student_id FROM users")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($ids as $id) recalculateStudent($pdo, $id);
    set_flash('success', 'SGPA, CGPA and percentage recalculated for every student.');
    redirect('semesters.php');
}

$rows = $pdo->query(
    "SELECT sm.*, u.name, u.department,
            (SELECT COUNT(*) FROM results r WHERE r.student_id = sm.student_id
              AND r.semester = sm.semester AND r.status = 'Published') AS published_rows,
            (SELECT COUNT(*) FROM results r WHERE r.student_id = sm.student_id
              AND r.semester = sm.semester) AS total_rows
     FROM semesters sm JOIN users u ON u.student_id = sm.student_id
     ORDER BY u.student_id, sm.semester"
)->fetchAll();

$LAYOUT = 'admin'; $ACTIVE = 'semesters'; $PAGE_TITLE = 'SGPA / CGPA';
include '../includes/header.php';
?>

<div class="card">
  <div class="card-head">
    <h3>Semester summary (<?= count($rows) ?> records)</h3>
    <div class="actions">
      <input type="search" data-filter="#semTable" placeholder="Search a student" style="max-width:260px">
      <a class="btn btn-primary btn-sm" href="semesters.php?action=recalc">Recalculate all</a>
    </div>
  </div>

  <p class="muted tiny">SGPA = &Sigma;(credit &times; grade point) &divide; &Sigma;credits for that semester.
     CGPA applies the same formula to every subject up to and including that semester.
     These rows are rewritten automatically whenever marks are saved.</p>

  <div class="table-wrap">
    <table class="data" id="semTable">
      <thead><tr><th>Roll number</th><th>Student</th><th>Department</th><th class="num">Semester</th>
        <th class="num">SGPA</th><th class="num">CGPA</th><th class="num">Percentage</th><th>Visible to student</th></tr></thead>
      <tbody>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td><?= e($r['student_id']) ?></td>
          <td><?= e($r['name']) ?></td>
          <td><?= e($r['department']) ?></td>
          <td class="num"><?= (int)$r['semester'] ?></td>
          <td class="num"><b><?= number_format($r['sgpa'], 2) ?></b></td>
          <td class="num"><?= number_format($r['cgpa'], 2) ?></td>
          <td class="num"><?= number_format($r['percentage'], 2) ?>%</td>
          <td><span class="badge <?= $r['published_rows'] ? 'b-pass' : 'b-draft' ?>">
            <?= $r['published_rows'] ? 'Published' : 'Draft' ?>
            (<?= (int)$r['published_rows'] ?>/<?= (int)$r['total_rows'] ?>)</span></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$rows): ?><tr><td colspan="8" class="empty">No marks have been entered yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include '../includes/footer.php'; ?>
