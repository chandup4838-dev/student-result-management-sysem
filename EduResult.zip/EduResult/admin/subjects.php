<?php
/* admin/subjects.php - full CRUD for subjects */
require_once '../includes/auth.php';
requireAdmin();

$departments = ['Computer Science & Engineering', 'AI & Data Science',
                'Electronics & Communication', 'Electrical & Electronics'];

$action = $_GET['action'] ?? 'list';
$editId = (int)($_GET['id'] ?? 0);
$error  = '';
$edit   = null;

if ($action === 'delete' && $editId) {
    $used = $pdo->prepare("SELECT COUNT(*) FROM results WHERE subject_id = ?");
    $used->execute([$editId]);
    if ($used->fetchColumn() > 0) {
        set_flash('error', 'Marks already exist for that subject. Delete those result rows first.');
    } else {
        $pdo->prepare("DELETE FROM subjects WHERE id = ?")->execute([$editId]);
        set_flash('success', 'Subject deleted.');
    }
    redirect('subjects.php');
}

if ($action === 'edit' && $editId) {
    $q = $pdo->prepare("SELECT * FROM subjects WHERE id = ?");
    $q->execute([$editId]);
    $edit = $q->fetch();
    if (!$edit) { set_flash('error', 'That subject no longer exists.'); redirect('subjects.php'); }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id           = (int)($_POST['id'] ?? 0);
    $subject_code = strtoupper(trim($_POST['subject_code'] ?? ''));
    $subject_name = trim($_POST['subject_name'] ?? '');
    $credits      = (int)($_POST['credits'] ?? 3);
    $department   = $_POST['department'] ?? '';
    $semester     = (int)($_POST['semester'] ?? 1);

    if ($subject_code === '' || $subject_name === '') {
        $error = 'Subject code and name are required.';
    } elseif ($credits < 1 || $credits > 6) {
        $error = 'Credits must be between 1 and 6.';
    } else {
        $dup = $pdo->prepare("SELECT COUNT(*) FROM subjects WHERE subject_code = ? AND id <> ?");
        $dup->execute([$subject_code, $id]);
        if ($dup->fetchColumn() > 0) {
            $error = 'That subject code is already in use.';
        } elseif ($id) {
            $pdo->prepare("UPDATE subjects SET subject_code=?, subject_name=?, credits=?, department=?, semester=? WHERE id=?")
                ->execute([$subject_code, $subject_name, $credits, $department, $semester, $id]);
            set_flash('success', 'Subject updated.');
            redirect('subjects.php');
        } else {
            $pdo->prepare("INSERT INTO subjects (subject_code, subject_name, credits, department, semester) VALUES (?,?,?,?,?)")
                ->execute([$subject_code, $subject_name, $credits, $department, $semester]);
            set_flash('success', 'Subject added.');
            redirect('subjects.php');
        }
    }
}

$filterDept = $_GET['dept'] ?? '';
$filterSem  = (int)($_GET['sem'] ?? 0);
$sql = "SELECT * FROM subjects WHERE 1";
$params = [];
if ($filterDept !== '') { $sql .= " AND department = ?"; $params[] = $filterDept; }
if ($filterSem)         { $sql .= " AND semester = ?";   $params[] = $filterSem; }
$sql .= " ORDER BY department, semester, subject_code";
$q = $pdo->prepare($sql); $q->execute($params);
$subjects = $q->fetchAll();

$LAYOUT = 'admin'; $ACTIVE = 'subjects'; $PAGE_TITLE = 'Subject Management';
include '../includes/header.php';
?>

<?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>

<div class="card">
  <div class="card-head"><h3><?= $edit ? 'Edit subject' : 'Add a subject' ?></h3>
    <?php if ($edit): ?><a class="btn btn-ghost btn-sm" href="subjects.php">Cancel</a><?php endif; ?></div>
  <form method="post">
    <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
    <div class="form-row">
      <div class="field"><label for="subject_code">Subject code</label>
        <input id="subject_code" name="subject_code" placeholder="CSE401" value="<?= e($edit['subject_code'] ?? '') ?>" required></div>
      <div class="field"><label for="subject_name">Subject name</label>
        <input id="subject_name" name="subject_name" placeholder="Computer Networks" value="<?= e($edit['subject_name'] ?? '') ?>" required></div>
    </div>
    <div class="form-row-3">
      <div class="field"><label for="credits">Credits</label>
        <select id="credits" name="credits"><?php for ($i=1;$i<=6;$i++): ?>
          <option value="<?= $i ?>" <?= (($edit['credits'] ?? 3)==$i)?'selected':'' ?>><?= $i ?></option>
        <?php endfor; ?></select></div>
      <div class="field"><label for="department">Department</label>
        <select id="department" name="department">
          <?php foreach ($departments as $d): ?>
            <option <?= (($edit['department'] ?? '') === $d) ? 'selected' : '' ?>><?= e($d) ?></option>
          <?php endforeach; ?></select></div>
      <div class="field"><label for="semester">Semester</label>
        <select id="semester" name="semester"><?php for ($i=1;$i<=8;$i++): ?>
          <option value="<?= $i ?>" <?= (($edit['semester'] ?? 0)==$i)?'selected':'' ?>>Semester <?= $i ?></option>
        <?php endfor; ?></select></div>
    </div>
    <button class="btn btn-primary" type="submit"><?= $edit ? 'Save changes' : 'Add subject' ?></button>
  </form>
</div>

<div class="card">
  <div class="card-head"><h3>Subjects (<?= count($subjects) ?>)</h3>
    <form method="get" class="toolbar" style="margin:0">
      <div class="field"><label for="dept">Department</label>
        <select id="dept" name="dept" onchange="this.form.submit()">
          <option value="">All departments</option>
          <?php foreach ($departments as $d): ?>
            <option <?= $filterDept === $d ? 'selected' : '' ?>><?= e($d) ?></option>
          <?php endforeach; ?></select></div>
      <div class="field"><label for="semf">Semester</label>
        <select id="semf" name="sem" onchange="this.form.submit()">
          <option value="0">All semesters</option>
          <?php for ($i=1;$i<=8;$i++): ?>
            <option value="<?= $i ?>" <?= $filterSem === $i ? 'selected' : '' ?>>Semester <?= $i ?></option>
          <?php endfor; ?></select></div>
    </form>
  </div>
  <div class="table-wrap">
    <table class="data" id="subjectsTable">
      <thead><tr><th>Code</th><th>Subject</th><th class="num">Credits</th><th>Department</th>
        <th class="num">Semester</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($subjects as $s): ?>
        <tr>
          <td><?= e($s['subject_code']) ?></td>
          <td><?= e($s['subject_name']) ?></td>
          <td class="num"><?= (int)$s['credits'] ?></td>
          <td><?= e($s['department']) ?></td>
          <td class="num"><?= (int)$s['semester'] ?></td>
          <td><div class="actions">
            <a class="btn btn-ghost btn-sm" href="subjects.php?action=edit&id=<?= (int)$s['id'] ?>">Edit</a>
            <a class="btn btn-danger btn-sm confirm-delete" href="subjects.php?action=delete&id=<?= (int)$s['id'] ?>">Delete</a>
          </div></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$subjects): ?><tr><td colspan="6" class="empty">No subjects match this filter.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include '../includes/footer.php'; ?>
