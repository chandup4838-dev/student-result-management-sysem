<?php
/* admin/logout.php - end the admin session */
require_once '../includes/auth.php';
$_SESSION = [];
session_destroy();
session_start();
set_flash('success', 'Admin signed out.');
header('Location: login.php');
exit;
