<?php
/* admin/login.php */
require_once '../includes/auth.php';

if (isAdmin()) redirect('dashboard.php');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $q = $pdo->prepare("SELECT * FROM admin WHERE username = ?");
    $q->execute([$username]);
    $admin = $q->fetch();

    if ($admin && password_verify($password, $admin['password'])) {
        session_regenerate_id(true);
        $_SESSION['admin_id']   = $admin['id'];
        $_SESSION['admin_user'] = $admin['username'];
        redirect('dashboard.php');
    } else {
        $error = 'Username or password is incorrect.';
    }
}

$LAYOUT = 'public';
$PAGE_TITLE = 'Admin Login';
$BASE = '../';
include '../includes/header.php';
?>
<div class="auth-wrap">
  <div class="auth-card">
    <div class="tabs">
      <a href="../login.php">Student</a>
      <a class="active" href="login.php">Admin</a>
    </div>

    <h2>Examination cell login</h2>
    <p class="muted">Staff accounts manage students, subjects, marks and publication.</p>

    <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>

    <form method="post" autocomplete="off">
      <div class="field"><label for="username">Username</label>
        <input id="username" name="username" value="<?= e($_POST['username'] ?? '') ?>" required></div>
      <div class="field"><label for="password">Password</label>
        <input type="password" id="password" name="password" required></div>
      <button class="btn btn-primary btn-block" type="submit">Sign in</button>
    </form>

    <div class="demo-box"><b>Demo account</b><br>
      Username <b>admin</b> &nbsp;&middot;&nbsp; Password <b>admin123</b></div>
    <p class="tiny muted" style="margin-top:1rem"><a href="../index.php">Back to home</a></p>
  </div>
</div>
<?php include '../includes/footer.php'; ?>
