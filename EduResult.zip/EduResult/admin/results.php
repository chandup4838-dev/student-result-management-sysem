<?php
/* admin/results.php - enter marks, calculate grades, publish results */
require_once '../includes/auth.php';
requireAdmin();

$error = '';
$edit  = null;

$students = $pdo->query("SELECT student_id, name, department, semester FROM users ORDER BY student_id")->fetchAll();
$subjects = $pdo->query("SELECT * FROM subjects ORDER BY department, semester, subject_code")->fetchAll();

/* ---------- which student / semester is being worked on ---------- */
$selStudent = $_GET['student'] ?? ($students[0]['student_id'] ?? '');
$selSem     = (int)($_GET['sem'] ?? 0);
if (!$selSem) {
    $s = $pdo->prepare("SELECT semester FROM users WHERE student_id = ?");
    $s->execute([$selStudent]);
    $selSem = (int)($s->fetchColumn() ?: 1);
}

/* ---------- DELETE one marks row ---------- */
if (($_GET['action'] ?? '') === 'delete' && !empty($_GET['id'])) {
    $id = (int)$_GET['id'];
    $row = $pdo->prepare("SELECT student_id FROM results WHERE id = ?");
    $row->execute([$id]);
    $owner = $row->fetchColumn();
    $pdo->prepare("DELETE FROM results WHERE id = ?")->execute([$id]);
    if ($owner) recalculateStudent($pdo, $owner);
    set_flash('success', 'Marks row deleted and SGPA recalculated.');
    redirect("results.php?student=" . urlencode($selStudent) . "&sem=$selSem");
}

/* ---------- PUBLISH / UNPUBLISH a whole semester ---------- */
if (($_GET['action'] ?? '') === 'publish' || ($_GET['action'] ?? '') === 'draft') {
    $new = ($_GET['action'] === 'publish') ? 'Published' : 'Draft';
    $pdo->prepare("UPDATE results SET status = ? WHERE student_id = ? AND semester = ?")
        ->execute([$new, $selStudent, $selSem]);
    recalculateStudent($pdo, $selStudent);
    set_flash('success', "Semester $selSem marked as $new.");
    redirect("results.php?student=" . urlencode($selStudent) . "&sem=$selSem");
}

/* ---------- load a row for editing ---------- */
if (($_GET['action'] ?? '') === 'edit' && !empty($_GET['id'])) {
    $q = $pdo->prepare("SELECT * FROM results WHERE id = ?");
    $q->execute([(int)$_GET['id']]);
    $edit = $q->fetch();
}

/* ---------- SAVE marks ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $id         = (int)($_POST['id'] ?? 0);
    $student_id = $_POST['student_id'] ?? '';
    $subject_id = (int)($_POST['subject_id'] ?? 0);
    $semester   = (int)($_POST['semester'] ?? 1);
    $internal   = (int)($_POST['internal_marks'] ?? 0);
    $external   = (int)($_POST['external_marks'] ?? 0);
    $status     = ($_POST['status'] ?? 'Draft') === 'Published' ? 'Published' : 'Draft';

    if ($student_id === '' || !$subject_id) {
        $error = 'Choose a student and a subject.';
    } elseif ($internal < 0 || $internal > MAX_INTERNAL) {
        $error = 'Internal marks must be between 0 and ' . MAX_INTERNAL . '.';
    } elseif ($external < 0 || $external > MAX_EXTERNAL) {
        $error = 'External marks must be between 0 and ' . MAX_EXTERNAL . '.';
    } else {
        /* the system calculates these - the admin never types a grade */
        $total = $internal + $external;
        $g     = calculateGrade($total);

        if ($id) {
            $pdo->prepare(
                "UPDATE results SET student_id=?, subject_id=?, semester=?, internal_marks=?, external_marks=?,
                 total_marks=?, grade=?, grade_point=?, status=? WHERE id=?"
            )->execute([$student_id, $subject_id, $semester, $internal, $external,
                        $total, $g['grade'], $g['point'], $status, $id]);
        } else {
            /* one row per student per subject */
            $pdo->prepare(
                "INSERT INTO results (student_id, subject_id, semester, internal_marks, external_marks,
                                      total_marks, grade, grade_point, status)
                 VALUES (?,?,?,?,?,?,?,?,?)
                 ON DUPLICATE KEY UPDATE semester=VALUES(semester), internal_marks=VALUES(internal_marks),
                   external_marks=VALUES(external_marks), total_marks=VALUES(total_marks),
                   grade=VALUES(grade), grade_point=VALUES(grade_point), status=VALUES(status)"
            )->execute([$student_id, $subject_id, $semester, $internal, $external,
                        $total, $g['grade'], $g['point'], $status]);
        }

        recalculateStudent($pdo, $student_id);      // SGPA / CGPA refreshed immediately
        set_flash('success', "Marks saved. Total $total, grade {$g['grade']}, grade point {$g['point']}.");
        redirect("results.php?student=" . urlencode($student_id) . "&sem=$semester");
    }
}

/* ---------- rows shown in the table (all statuses - this is the admin view) ---------- */
$q = $pdo->prepare(
    "SELECT r.*, s.subject_code, s.subject_name, s.credits
     FROM results r JOIN subjects s ON s.id = r.subject_id
     WHERE r.student_id = ? AND r.semester = ? ORDER BY s.subject_code"
);
$q->execute([$selStudent, $selSem]);
$rows = $q->fetchAll();
$summary = summarise($rows);

$semStatus = 'None';
if ($rows) {
    $pub = 0;
    foreach ($rows as $r) if ($r['status'] === 'Published') $pub++;
    $semStatus = ($pub === count($rows)) ? 'Published' : ($pub ? 'Partly published' : 'Draft');
}

$LAYOUT = 'admin'; $ACTIVE = 'results'; $PAGE_TITLE = 'Result Management';
include '../includes/header.php';
?>

<?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>

<div class="card">
  <div class="card-head"><h3>Choose a student and semester</h3></div>
  <form method="get" class="toolbar">
    <div class="field"><label for="student">Student</label>
      <select id="student" name="student" onchange="this.form.submit()" style="min-width:280px">
        <?php foreach ($students as $s): ?>
          <option value="<?= e($s['student_id']) ?>" <?= $selStudent === $s['student_id'] ? 'selected' : '' ?>>
            <?= e($s['student_id']) ?> — <?= e($s['name']) ?>
          </option>
        <?php endforeach; ?>
      </select></div>
    <div class="field"><label for="sem">Semester</label>
      <select id="sem" name="sem" onchange="this.form.submit()">
        <?php for ($i=1;$i<=8;$i++): ?>
          <option value="<?= $i ?>" <?= $selSem === $i ? 'selected' : '' ?>>Semester <?= $i ?></option>
        <?php endfor; ?>
      </select></div>
  </form>
</div>

<div class="card">
  <div class="card-head">
    <h3><?= $edit ? 'Edit marks' : 'Enter marks' ?></h3>
    <?php if ($edit): ?>
      <a class="btn btn-ghost btn-sm" href="results.php?student=<?= urlencode($selStudent) ?>&sem=<?= $selSem ?>">Cancel</a>
    <?php endif; ?>
  </div>

  <form method="post">
    <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
    <div class="form-row-3">
      <div class="field"><label for="student_id">Student</label>
        <select id="student_id" name="student_id">
          <?php foreach ($students as $s):
            $chosen = $edit ? $edit['student_id'] : $selStudent; ?>
            <option value="<?= e($s['student_id']) ?>" <?= $chosen === $s['student_id'] ? 'selected' : '' ?>>
              <?= e($s['student_id']) ?> — <?= e($s['name']) ?></option>
          <?php endforeach; ?>
        </select></div>
      <div class="field"><label for="semester">Semester</label>
        <select id="semester" name="semester"><?php for ($i=1;$i<=8;$i++):
            $chosen = $edit ? (int)$edit['semester'] : $selSem; ?>
          <option value="<?= $i ?>" <?= $chosen === $i ? 'selected' : '' ?>>Semester <?= $i ?></option>
        <?php endfor; ?></select></div>
      <div class="field"><label for="subject_id">Subject</label>
        <select id="subject_id" name="subject_id">
          <?php foreach ($subjects as $s): ?>
            <option value="<?= (int)$s['id'] ?>" <?= (int)($edit['subject_id'] ?? 0) === (int)$s['id'] ? 'selected' : '' ?>>
              <?= e($s['subject_code']) ?> — <?= e($s['subject_name']) ?> (Sem <?= (int)$s['semester'] ?>, <?= (int)$s['credits'] ?> cr)
            </option>
          <?php endforeach; ?>
        </select></div>
    </div>
    <div class="form-row-3">
      <div class="field"><label for="internal_marks">Internal marks (0 - <?= MAX_INTERNAL ?>)</label>
        <input type="number" id="internal_marks" name="internal_marks" min="0" max="<?= MAX_INTERNAL ?>"
               value="<?= (int)($edit['internal_marks'] ?? 0) ?>"></div>
      <div class="field"><label for="external_marks">External marks (0 - <?= MAX_EXTERNAL ?>)</label>
        <input type="number" id="external_marks" name="external_marks" min="0" max="<?= MAX_EXTERNAL ?>"
               value="<?= (int)($edit['external_marks'] ?? 0) ?>"></div>
      <div class="field"><label for="status">Status</label>
        <select id="status" name="status">
          <option value="Draft" <?= (($edit['status'] ?? 'Draft') === 'Draft') ? 'selected' : '' ?>>Draft — hidden from the student</option>
          <option value="Published" <?= (($edit['status'] ?? '') === 'Published') ? 'selected' : '' ?>>Published — visible to the student</option>
        </select></div>
    </div>

    <div class="alert alert-info" id="gradePreview">Total and grade appear here as you type.</div>
    <button class="btn btn-primary" type="submit"><?= $edit ? 'Save marks' : 'Save marks' ?></button>
    <span class="tiny muted" style="margin-left:.6rem">Grade, grade point and pass/fail are calculated by the system.</span>
  </form>
</div>

<div class="card">
  <div class="card-head">
    <h3>Semester <?= $selSem ?> — <?= e($selStudent) ?></h3>
    <div class="actions">
      <span class="badge <?= $semStatus === 'Published' ? 'b-pass' : 'b-draft' ?>"><?= e($semStatus) ?></span>
      <a class="btn btn-gold btn-sm" href="results.php?student=<?= urlencode($selStudent) ?>&sem=<?= $selSem ?>&action=publish">Publish result</a>
      <a class="btn btn-ghost btn-sm" href="results.php?student=<?= urlencode($selStudent) ?>&sem=<?= $selSem ?>&action=draft">Move back to draft</a>
    </div>
  </div>

  <?php if (!$rows): ?>
    <p class="empty">No marks recorded for this student in semester <?= $selSem ?> yet.</p>
  <?php else: ?>
  <div class="table-wrap">
    <table class="data">
      <thead><tr><th>Code</th><th>Subject</th><th class="num">Cr</th><th class="num">Int</th><th class="num">Ext</th>
        <th class="num">Total</th><th>Grade</th><th class="num">GP</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td><?= e($r['subject_code']) ?></td>
          <td><?= e($r['subject_name']) ?></td>
          <td class="num"><?= (int)$r['credits'] ?></td>
          <td class="num"><?= (int)$r['internal_marks'] ?></td>
          <td class="num"><?= (int)$r['external_marks'] ?></td>
          <td class="num"><b><?= (int)$r['total_marks'] ?></b></td>
          <td><span class="<?= gradeClass($r['grade']) ?>"><?= e($r['grade']) ?></span></td>
          <td class="num"><?= (int)$r['grade_point'] ?></td>
          <td><span class="badge <?= $r['status'] === 'Published' ? 'b-pass' : 'b-draft' ?>"><?= e($r['status']) ?></span></td>
          <td><div class="actions">
            <a class="btn btn-ghost btn-sm" href="results.php?student=<?= urlencode($selStudent) ?>&sem=<?= $selSem ?>&action=edit&id=<?= (int)$r['id'] ?>">Edit</a>
            <a class="btn btn-danger btn-sm confirm-delete" href="results.php?student=<?= urlencode($selStudent) ?>&sem=<?= $selSem ?>&action=delete&id=<?= (int)$r['id'] ?>">Delete</a>
          </div></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <div class="ms-summary" style="margin-top:1rem;border-radius:10px">
    <div><b><?= $summary['total'] ?>/<?= $summary['max'] ?></b><small>Total marks</small></div>
    <div><b><?= number_format($summary['percentage'], 2) ?>%</b><small>Percentage</small></div>
    <div><b><?= number_format($summary['sgpa'], 2) ?></b><small>SGPA</small></div>
    <div><b><?= $summary['credits'] ?></b><small>Credits</small></div>
    <div><b style="color:<?= $summary['status'] === 'PASS' ? 'var(--pass)' : 'var(--fail)' ?>"><?= $summary['status'] ?></b><small>Semester result</small></div>
  </div>
  <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>
