<?php
/* admin/students.php - full CRUD for students */
require_once '../includes/auth.php';
requireAdmin();

$departments = ['Computer Science & Engineering', 'AI & Data Science',
                'Electronics & Communication', 'Electrical & Electronics'];

$action = $_GET['action'] ?? 'list';
$editId = (int)($_GET['id'] ?? 0);
$error  = '';
$edit   = null;

/* ---------- DELETE ---------- */
if ($action === 'delete' && $editId) {
    $pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$editId]);
    set_flash('success', 'Student deleted along with their result records.');
    redirect('students.php');
}

/* ---------- load the row being edited ---------- */
if ($action === 'edit' && $editId) {
    $q = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $q->execute([$editId]);
    $edit = $q->fetch();
    if (!$edit) { set_flash('error', 'That student no longer exists.'); redirect('students.php'); }
}

/* ---------- CREATE / UPDATE ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $id         = (int)($_POST['id'] ?? 0);
    $student_id = trim($_POST['student_id'] ?? '');
    $name       = trim($_POST['name'] ?? '');
    $email      = trim($_POST['email'] ?? '');
    $phone      = trim($_POST['phone'] ?? '');
    $department = $_POST['department'] ?? '';
    $year       = (int)($_POST['year'] ?? 1);
    $semester   = (int)($_POST['semester'] ?? 1);
    $password   = $_POST['password'] ?? '';

    if ($student_id === '' || $name === '' || $email === '') {
        $error = 'Roll number, name and email are required.';
    } else {
        $dup = $pdo->prepare("SELECT COUNT(*) FROM users WHERE (student_id = ? OR email = ?) AND id <> ?");
        $dup->execute([$student_id, $email, $id]);
        if ($dup->fetchColumn() > 0) {
            $error = 'Another student already uses that roll number or email.';
        } elseif ($id) {
            /* UPDATE */
            if ($password !== '') {
                $u = $pdo->prepare("UPDATE users SET student_id=?, name=?, email=?, phone=?, department=?, year=?, semester=?, password=? WHERE id=?");
                $u->execute([$student_id, $name, $email, $phone, $department, $year, $semester,
                             password_hash($password, PASSWORD_DEFAULT), $id]);
            } else {
                $u = $pdo->prepare("UPDATE users SET student_id=?, name=?, email=?, phone=?, department=?, year=?, semester=? WHERE id=?");
                $u->execute([$student_id, $name, $email, $phone, $department, $year, $semester, $id]);
            }
            set_flash('success', 'Student updated.');
            redirect('students.php');
        } else {
            /* INSERT */
            if (strlen($password) < 6) {
                $error = 'Give the student a password of at least 6 characters.';
            } else {
                $i = $pdo->prepare("INSERT INTO users (student_id,name,email,phone,department,year,semester,password) VALUES (?,?,?,?,?,?,?,?)");
                $i->execute([$student_id, $name, $email, $phone, $department, $year, $semester,
                             password_hash($password, PASSWORD_DEFAULT)]);
                set_flash('success', 'Student added.');
                redirect('students.php');
            }
        }
    }
}

/* ---------- list ---------- */
$students = $pdo->query(
    "SELECT u.*, (SELECT COUNT(*) FROM results r WHERE r.student_id = u.student_id) AS result_count
     FROM users u ORDER BY u.department, u.student_id"
)->fetchAll();

$LAYOUT = 'admin'; $ACTIVE = 'students'; $PAGE_TITLE = 'Student Management';
include '../includes/header.php';
?>

<?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>

<div class="card">
  <div class="card-head"><h3><?= $edit ? 'Edit student' : 'Add a student' ?></h3>
    <?php if ($edit): ?><a class="btn btn-ghost btn-sm" href="students.php">Cancel</a><?php endif; ?></div>

  <form method="post">
    <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
    <div class="form-row-3">
      <div class="field"><label for="student_id">Roll number</label>
        <input id="student_id" name="student_id" value="<?= e($edit['student_id'] ?? '') ?>" required></div>
      <div class="field"><label for="name">Name</label>
        <input id="name" name="name" value="<?= e($edit['name'] ?? '') ?>" required></div>
      <div class="field"><label for="email">Email</label>
        <input type="email" id="email" name="email" value="<?= e($edit['email'] ?? '') ?>" required></div>
    </div>
    <div class="form-row-3">
      <div class="field"><label for="phone">Phone</label>
        <input id="phone" name="phone" value="<?= e($edit['phone'] ?? '') ?>"></div>
      <div class="field"><label for="department">Department</label>
        <select id="department" name="department">
          <?php foreach ($departments as $d): ?>
            <option <?= (($edit['department'] ?? '') === $d) ? 'selected' : '' ?>><?= e($d) ?></option>
          <?php endforeach; ?>
        </select></div>
      <div class="field"><label for="password">Password <?= $edit ? '(leave blank to keep)' : '' ?></label>
        <input type="text" id="password" name="password" placeholder="<?= $edit ? 'unchanged' : 'student123' ?>"></div>
    </div>
    <div class="form-row">
      <div class="field"><label for="year">Year</label>
        <select id="year" name="year"><?php for ($i=1;$i<=4;$i++): ?>
          <option value="<?= $i ?>" <?= (($edit['year'] ?? 0)==$i)?'selected':'' ?>>Year <?= $i ?></option>
        <?php endfor; ?></select></div>
      <div class="field"><label for="semester">Current semester</label>
        <select id="semester" name="semester"><?php for ($i=1;$i<=8;$i++): ?>
          <option value="<?= $i ?>" <?= (($edit['semester'] ?? 0)==$i)?'selected':'' ?>>Semester <?= $i ?></option>
        <?php endfor; ?></select></div>
    </div>
    <button class="btn btn-primary" type="submit"><?= $edit ? 'Save changes' : 'Add student' ?></button>
  </form>
</div>

<div class="card">
  <div class="card-head"><h3>Students (<?= count($students) ?>)</h3>
    <input type="search" data-filter="#studentsTable" placeholder="Search name, roll number or department" style="max-width:320px"></div>
  <div class="table-wrap">
    <table class="data" id="studentsTable">
      <thead><tr><th>Roll number</th><th>Name</th><th>Email</th><th>Department</th>
        <th class="num">Year</th><th class="num">Sem</th><th class="num">Marks rows</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($students as $s): ?>
        <tr>
          <td><?= e($s['student_id']) ?></td>
          <td><?= e($s['name']) ?></td>
          <td class="muted"><?= e($s['email']) ?></td>
          <td><?= e($s['department']) ?></td>
          <td class="num"><?= (int)$s['year'] ?></td>
          <td class="num"><?= (int)$s['semester'] ?></td>
          <td class="num"><?= (int)$s['result_count'] ?></td>
          <td><div class="actions">
            <a class="btn btn-ghost btn-sm" href="students.php?action=edit&id=<?= (int)$s['id'] ?>">Edit</a>
            <a class="btn btn-danger btn-sm confirm-delete" href="students.php?action=delete&id=<?= (int)$s['id'] ?>">Delete</a>
          </div></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include '../includes/footer.php'; ?>
