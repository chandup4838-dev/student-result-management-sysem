<?php
/* admin/dashboard.php */
require_once '../includes/auth.php';
requireAdmin();

$totalStudents = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalSubjects = (int)$pdo->query("SELECT COUNT(*) FROM subjects")->fetchColumn();
$totalResults  = (int)$pdo->query("SELECT COUNT(*) FROM results")->fetchColumn();
$totalDepts    = (int)$pdo->query("SELECT COUNT(DISTINCT department) FROM users")->fetchColumn();
$published     = (int)$pdo->query("SELECT COUNT(*) FROM results WHERE status='Published'")->fetchColumn();
$draft         = $totalResults - $published;

$recent = $pdo->query(
    "SELECT r.*, u.name, s.subject_code, s.subject_name
     FROM results r
     JOIN users u    ON u.student_id = r.student_id
     JOIN subjects s ON s.id = r.subject_id
     ORDER BY r.id DESC LIMIT 12"
)->fetchAll();

/* department wise pass summary */
$deptStats = $pdo->query(
    "SELECT u.department,
            COUNT(*) AS total,
            SUM(CASE WHEN r.total_marks >= " . PASS_MARK . " THEN 1 ELSE 0 END) AS passed
     FROM results r JOIN users u ON u.student_id = r.student_id
     GROUP BY u.department ORDER BY u.department"
)->fetchAll();

$LAYOUT = 'admin'; $ACTIVE = 'dashboard'; $PAGE_TITLE = 'Admin Dashboard';
include '../includes/header.php';
?>

<div class="cards">
  <div class="stat-card"><small>Total students</small><b><?= $totalStudents ?></b><span class="sub">registered accounts</span></div>
  <div class="stat-card gold"><small>Total subjects</small><b><?= $totalSubjects ?></b><span class="sub">across all semesters</span></div>
  <div class="stat-card pass"><small>Total results</small><b><?= $totalResults ?></b><span class="sub"><?= $published ?> published, <?= $draft ?> draft</span></div>
  <div class="stat-card"><small>Departments</small><b><?= $totalDepts ?></b><span class="sub">offering programmes</span></div>
</div>

<div class="card">
  <div class="card-head"><h3>Quick actions</h3></div>
  <div class="quick-links">
    <a class="btn btn-primary btn-sm" href="students.php">Add a student</a>
    <a class="btn btn-ghost btn-sm" href="subjects.php">Add a subject</a>
    <a class="btn btn-gold btn-sm" href="results.php">Enter marks</a>
    <a class="btn btn-ghost btn-sm" href="semesters.php">Review SGPA / CGPA</a>
  </div>
</div>

<div class="card">
  <div class="card-head"><h3>Recently entered results</h3>
    <a class="btn btn-ghost btn-sm" href="results.php">Open result management</a></div>
  <?php if (!$recent): ?>
    <p class="empty">No marks have been entered yet. Start from Result Management.</p>
  <?php else: ?>
  <div class="table-wrap">
    <table class="data">
      <thead><tr><th>Roll number</th><th>Student</th><th>Subject</th><th class="num">Sem</th>
        <th class="num">Internal</th><th class="num">External</th><th class="num">Total</th>
        <th>Grade</th><th>Status</th></tr></thead>
      <tbody>
      <?php foreach ($recent as $r): ?>
        <tr>
          <td><?= e($r['student_id']) ?></td>
          <td><?= e($r['name']) ?></td>
          <td><?= e($r['subject_code']) ?> — <?= e($r['subject_name']) ?></td>
          <td class="num"><?= (int)$r['semester'] ?></td>
          <td class="num"><?= (int)$r['internal_marks'] ?></td>
          <td class="num"><?= (int)$r['external_marks'] ?></td>
          <td class="num"><b><?= (int)$r['total_marks'] ?></b></td>
          <td><span class="<?= gradeClass($r['grade']) ?>"><?= e($r['grade']) ?></span></td>
          <td><span class="badge <?= $r['status'] === 'Published' ? 'b-pass' : 'b-draft' ?>"><?= e($r['status']) ?></span></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<div class="card">
  <div class="card-head"><h3>Pass rate by department</h3></div>
  <?php foreach ($deptStats as $d):
      $rate = $d['total'] ? round($d['passed'] / $d['total'] * 100) : 0; ?>
    <div class="bar-row">
      <span><?= e($d['department']) ?></span>
      <span class="bar-track"><span class="bar-fill <?= $rate >= 90 ? 'top' : '' ?>" data-width="<?= $rate ?>"></span></span>
      <span class="bar-val"><?= $rate ?>%</span>
    </div>
  <?php endforeach; ?>
  <p class="tiny muted" style="margin:0">Share of subject entries with total marks of <?= PASS_MARK ?> or more.</p>
</div>

<?php include '../includes/footer.php'; ?>
