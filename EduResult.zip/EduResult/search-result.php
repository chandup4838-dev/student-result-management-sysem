<?php
/* search-result.php - public result check by roll number + semester */
require_once 'includes/config.php';
if (session_status() === PHP_SESSION_NONE) session_start();

$error = ''; $student = null; $rows = []; $summary = null; $semRow = null;
$roll = trim($_GET['roll'] ?? '');
$semester = (int)($_GET['semester'] ?? 0);

if ($roll !== '' && $semester > 0) {

    /* only public columns are selected - the password hash never leaves the database */
    $q = $pdo->prepare("SELECT student_id, name, department, year FROM users WHERE student_id = ?");
    $q->execute([$roll]);
    $student = $q->fetch();

    if (!$student) {
        $error = 'No student is registered with that roll number.';
    } else {
        $rows = getResultRows($pdo, $roll, $semester, true);   // published rows only
        if (!$rows) {
            $error = 'The result for semester ' . $semester . ' has not been published for this roll number.';
            $student = null;
        } else {
            $summary = summarise($rows);
            $s = $pdo->prepare("SELECT * FROM semesters WHERE student_id=? AND semester=?");
            $s->execute([$roll, $semester]);
            $semRow = $s->fetch();
        }
    }
}

$LAYOUT = 'public';
$PAGE_TITLE = 'Check Result';
include 'includes/header.php';
?>

<div class="container" style="padding:2.5rem 0">
  <div class="card" style="max-width:720px;margin-inline:auto">
    <h2>Check your result</h2>
    <p class="muted">Enter your roll number and semester. Only published results are shown, and no personal
       contact details or passwords are displayed here.</p>

    <form method="get" class="form-row">
      <div class="field"><label for="roll">Roll number</label>
        <input id="roll" name="roll" value="<?= e($roll) ?>" placeholder="CSE2021001" required></div>
      <div class="field"><label for="semester">Semester</label>
        <select id="semester" name="semester">
          <?php for ($i = 1; $i <= 8; $i++): ?>
            <option value="<?= $i ?>" <?= $semester === $i ? 'selected' : '' ?>>Semester <?= $i ?></option>
          <?php endfor; ?>
        </select></div>
      <div class="field" style="grid-column:1/-1">
        <button class="btn btn-primary btn-block" type="submit">Search result</button></div>
    </form>

    <?php if ($error): ?><div class="alert alert-error" style="margin:0"><?= e($error) ?></div><?php endif; ?>
  </div>

  <?php if ($student && $rows): ?>
  <div class="marksheet" style="margin-top:1.8rem">
    <div class="ms-head">
      <div class="ms-logo">E</div>
      <div>
        <h2><?= e(COLLEGE_NAME) ?></h2>
        <p><?= e(COLLEGE_SUB) ?></p>
        <p class="ms-title">Published result — Semester <?= $semester ?></p>
      </div>
    </div>

    <div class="ms-info">
      <div><span>Student name</span><strong><?= e($student['name']) ?></strong></div>
      <div><span>Roll number</span><strong><?= e($student['student_id']) ?></strong></div>
      <div><span>Department</span><strong><?= e($student['department']) ?></strong></div>
      <div><span>Year</span><strong><?= (int)$student['year'] ?></strong></div>
      <div><span>Semester</span><strong><?= $semester ?></strong></div>
      <div><span>Academic year</span><strong><?= e(ACADEMIC_YEAR) ?></strong></div>
    </div>

    <div class="ms-body">
      <div class="table-wrap">
        <table class="data">
          <thead><tr><th>Subject code</th><th>Subject name</th><th class="num">Internal</th>
            <th class="num">External</th><th class="num">Total</th><th>Grade</th>
            <th class="num">Grade point</th><th>Result</th></tr></thead>
          <tbody>
          <?php foreach ($rows as $r): ?>
            <tr>
              <td><?= e($r['subject_code']) ?></td>
              <td><?= e($r['subject_name']) ?></td>
              <td class="num"><?= (int)$r['internal_marks'] ?></td>
              <td class="num"><?= (int)$r['external_marks'] ?></td>
              <td class="num"><b><?= (int)$r['total_marks'] ?></b></td>
              <td><span class="<?= gradeClass($r['grade']) ?>"><?= e($r['grade']) ?></span></td>
              <td class="num"><?= (int)$r['grade_point'] ?></td>
              <td><span class="badge <?= $r['total_marks'] >= PASS_MARK ? 'b-pass' : 'b-fail' ?>">
                <?= $r['total_marks'] >= PASS_MARK ? 'PASS' : 'FAIL' ?></span></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="ms-summary">
      <div><b><?= $summary['total'] ?> / <?= $summary['max'] ?></b><small>Total marks</small></div>
      <div><b><?= number_format($summary['percentage'], 2) ?>%</b><small>Percentage</small></div>
      <div><b><?= number_format($summary['sgpa'], 2) ?></b><small>SGPA</small></div>
      <div><b><?= $semRow ? number_format($semRow['cgpa'], 2) : '-' ?></b><small>CGPA</small></div>
      <div><b style="color:<?= $summary['status'] === 'PASS' ? 'var(--pass)' : 'var(--fail)' ?>"><?= $summary['status'] ?></b><small>Status</small></div>
    </div>

    <div class="ms-foot">
      <div><p style="margin:0">Date of publication: <b><?= date('d M Y') ?></b></p></div>
      <div class="actions no-print">
        <button class="btn btn-primary btn-sm" data-print>Print result</button>
        <a class="btn btn-ghost btn-sm" href="login.php">Log in for full analysis</a>
      </div>
      <div class="sign"><i></i>Controller of Examinations</div>
    </div>
  </div>
  <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
