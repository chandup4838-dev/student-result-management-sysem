<?php
/* result.php - the official marksheet for one semester */
require_once 'includes/auth.php';
requireStudent();

$student = currentStudent($pdo);
$sid = $student['student_id'];

/* which semesters may this student see? only published ones */
$q = $pdo->prepare("SELECT DISTINCT semester FROM results WHERE student_id=? AND status='Published' ORDER BY semester");
$q->execute([$sid]);
$openSemesters = $q->fetchAll(PDO::FETCH_COLUMN);

$semester = isset($_GET['sem']) ? (int)$_GET['sem'] : (int)(end($openSemesters) ?: 0);
if ($openSemesters && !in_array($semester, array_map('intval', $openSemesters), true)) {
    $semester = (int)end($openSemesters);
}

$rows    = $semester ? getResultRows($pdo, $sid, $semester) : [];
$summary = summarise($rows);

/* stored SGPA / CGPA for this semester */
$sem = $pdo->prepare("SELECT * FROM semesters WHERE student_id=? AND semester=?");
$sem->execute([$sid, $semester]);
$semRow = $sem->fetch();
$cgpa = $semRow ? $semRow['cgpa'] : 0;

$LAYOUT = 'student'; $ACTIVE = 'result'; $PAGE_TITLE = 'View Result';
include 'includes/header.php';
?>

<div class="card no-print">
  <div class="card-head">
    <h3>Statement of marks</h3>
    <div class="actions">
      <form method="get" style="display:flex;gap:.5rem;align-items:center">
        <label for="sem" class="tiny muted">Semester</label>
        <select id="sem" name="sem" onchange="this.form.submit()" style="width:auto">
          <?php foreach ($openSemesters as $s): ?>
            <option value="<?= (int)$s ?>" <?= $semester == $s ? 'selected' : '' ?>>Semester <?= (int)$s ?></option>
          <?php endforeach; ?>
        </select>
      </form>
      <button class="btn btn-primary btn-sm" data-print>Print result</button>
      <button class="btn btn-gold btn-sm" data-print>Save as PDF</button>
    </div>
  </div>
  <p class="muted tiny" style="margin:0">In the print dialog choose <b>Save as PDF</b> as the destination to download the marksheet.</p>
</div>

<?php if (!$rows): ?>
  <div class="card"><p class="empty">No published result is available for your account yet.</p></div>
<?php else: ?>

<div class="marksheet">
  <div class="ms-head">
    <div class="ms-logo">E</div>
    <div>
      <h2><?= e(COLLEGE_NAME) ?></h2>
      <p><?= e(COLLEGE_SUB) ?></p>
      <p class="ms-title">Office of the Controller of Examinations — Statement of Marks</p>
    </div>
  </div>

  <div class="ms-info">
    <div><span>Student name</span><strong><?= e($student['name']) ?></strong></div>
    <div><span>Roll number</span><strong><?= e($student['student_id']) ?></strong></div>
    <div><span>Department</span><strong><?= e($student['department']) ?></strong></div>
    <div><span>Year</span><strong><?= (int)$student['year'] ?></strong></div>
    <div><span>Semester</span><strong><?= (int)$semester ?></strong></div>
    <div><span>Academic year</span><strong><?= e(ACADEMIC_YEAR) ?></strong></div>
  </div>

  <div class="ms-body">
    <div class="table-wrap">
      <table class="data">
        <thead>
          <tr>
            <th>Subject code</th><th>Subject name</th><th class="num">Credits</th>
            <th class="num">Internal (<?= MAX_INTERNAL ?>)</th><th class="num">External (<?= MAX_EXTERNAL ?>)</th>
            <th class="num">Total (<?= MAX_TOTAL ?>)</th><th>Grade</th><th class="num">Grade point</th><th>Result</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td><?= e($r['subject_code']) ?></td>
            <td><?= e($r['subject_name']) ?></td>
            <td class="num"><?= (int)$r['credits'] ?></td>
            <td class="num"><?= (int)$r['internal_marks'] ?></td>
            <td class="num"><?= (int)$r['external_marks'] ?></td>
            <td class="num"><b><?= (int)$r['total_marks'] ?></b></td>
            <td><span class="<?= gradeClass($r['grade']) ?>"><?= e($r['grade']) ?></span></td>
            <td class="num"><?= (int)$r['grade_point'] ?></td>
            <td><span class="badge <?= $r['total_marks'] >= PASS_MARK ? 'b-pass' : 'b-fail' ?>">
              <?= $r['total_marks'] >= PASS_MARK ? 'PASS' : 'FAIL' ?></span></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <p class="tiny muted" style="margin-top:.8rem">
      Total marks = internal + external. A subject is cleared at <?= PASS_MARK ?> marks or above.
      SGPA = &Sigma;(credit &times; grade point) &divide; &Sigma;credits.
    </p>
  </div>

  <div class="ms-summary">
    <div><b><?= $summary['total'] ?> / <?= $summary['max'] ?></b><small>Total marks</small></div>
    <div><b><?= number_format($summary['percentage'], 2) ?>%</b><small>Percentage</small></div>
    <div><b><?= number_format($summary['sgpa'], 2) ?></b><small>SGPA</small></div>
    <div><b><?= number_format($cgpa, 2) ?></b><small>CGPA</small></div>
    <div><b><?= $summary['passed'] ?> / <?= $summary['subjects'] ?></b><small>Subjects cleared</small></div>
  </div>

  <div class="ms-foot">
    <div>
      <p style="margin:0">Date of publication: <b><?= date('d M Y') ?></b></p>
      <p style="margin:.2rem 0 0" class="tiny">This statement is computer generated from the examination database.</p>
    </div>
    <div class="result-stamp <?= $summary['status'] === 'FAIL' ? 'fail' : '' ?>"><?= $summary['status'] ?></div>
    <div class="sign"><i></i>Controller of Examinations</div>
  </div>
</div>

<div class="card no-print" style="margin-top:1.4rem">
  <div class="card-head"><h3>Want to know what these numbers mean?</h3>
    <a class="btn btn-primary btn-sm" href="performance.php?sem=<?= (int)$semester ?>">Open performance analysis</a></div>
  <p class="muted" style="margin:0">See your strongest and weakest subject, your average marks and how this semester compares with the previous ones.</p>
</div>

<?php endif; ?>
<?php include 'includes/footer.php'; ?>
