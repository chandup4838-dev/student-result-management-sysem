<?php
/* profile.php - student profile + password change */
require_once 'includes/auth.php';
requireStudent();

$student = currentStudent($pdo);
$sid = $student['student_id'];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (($_POST['action'] ?? '') === 'details') {
        $name  = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Enter a valid name and email address.';
        } else {
            $u = $pdo->prepare("UPDATE users SET name=?, email=?, phone=? WHERE student_id=?");
            $u->execute([$name, $email, $phone, $sid]);
            $_SESSION['student_name'] = $name;
            set_flash('success', 'Profile updated.');
            redirect('profile.php');
        }
    }

    if (($_POST['action'] ?? '') === 'password') {
        $old = $_POST['old_password'] ?? '';
        $new = $_POST['new_password'] ?? '';
        $rep = $_POST['repeat_password'] ?? '';
        if (!password_verify($old, $student['password'])) {
            $error = 'Your current password is wrong.';
        } elseif (strlen($new) < 6) {
            $error = 'The new password needs at least 6 characters.';
        } elseif ($new !== $rep) {
            $error = 'The two new passwords do not match.';
        } else {
            $hash = password_hash($new, PASSWORD_DEFAULT);
            $pdo->prepare("UPDATE users SET password=? WHERE student_id=?")->execute([$hash, $sid]);
            set_flash('success', 'Password changed.');
            redirect('profile.php');
        }
    }
}

$LAYOUT = 'student'; $ACTIVE = 'profile'; $PAGE_TITLE = 'Profile';
include 'includes/header.php';
?>

<?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>

<div class="card">
  <div class="card-head">
    <div style="display:flex;align-items:center;gap:1rem">
      <div class="avatar" style="width:64px;height:64px;font-size:1.3rem"><?= e(initials($student['name'])) ?></div>
      <div>
        <h3 style="margin:0"><?= e($student['name']) ?></h3>
        <p class="muted" style="margin:0"><?= e($student['student_id']) ?> &middot; <?= e($student['department']) ?></p>
      </div>
    </div>
    <span class="badge b-pass">Year <?= (int)$student['year'] ?> &middot; Semester <?= (int)$student['semester'] ?></span>
  </div>
</div>

<div class="grid-2">
  <div class="card">
    <h3>Contact details</h3>
    <form method="post">
      <input type="hidden" name="action" value="details">
      <div class="field"><label for="name">Full name</label>
        <input id="name" name="name" value="<?= e($student['name']) ?>" required></div>
      <div class="field"><label for="email">Email</label>
        <input type="email" id="email" name="email" value="<?= e($student['email']) ?>" required></div>
      <div class="field"><label for="phone">Phone</label>
        <input id="phone" name="phone" value="<?= e($student['phone']) ?>"></div>
      <p class="tiny muted">Department, year and semester can only be changed by the examination cell.</p>
      <button class="btn btn-primary" type="submit">Save changes</button>
    </form>
  </div>

  <div class="card">
    <h3>Change password</h3>
    <form method="post">
      <input type="hidden" name="action" value="password">
      <div class="field"><label for="old_password">Current password</label>
        <input type="password" id="old_password" name="old_password" required></div>
      <div class="field"><label for="new_password">New password</label>
        <input type="password" id="new_password" name="new_password" required></div>
      <div class="field"><label for="repeat_password">Repeat new password</label>
        <input type="password" id="repeat_password" name="repeat_password" required></div>
      <p class="tiny muted">Passwords are stored as a bcrypt hash created by <code>password_hash()</code>.</p>
      <button class="btn btn-primary" type="submit">Update password</button>
    </form>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
