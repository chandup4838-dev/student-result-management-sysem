<?php
/* dashboard.php - student dashboard */
require_once 'includes/auth.php';
requireStudent();

$student = currentStudent($pdo);
if (!$student) { redirect('logout.php'); }

$sid      = $student['student_id'];
$lastSem  = lastPublishedSemester($pdo, $sid);          // 0 if nothing is published yet
$rows     = $lastSem ? getResultRows($pdo, $sid, $lastSem) : [];
$summary  = summarise($rows);

/* overall figures across every published semester */
$q = $pdo->prepare(
    "SELECT r.total_marks, r.grade_point, s.credits
     FROM results r JOIN subjects s ON s.id = r.subject_id
     WHERE r.student_id = ? AND r.status = 'Published'"
);
$q->execute([$sid]);
$all = $q->fetchAll();

$points = 0; $credits = 0; $marks = 0; $max = 0; $passed = 0; $failed = 0;
foreach ($all as $r) {
    $points  += $r['credits'] * $r['grade_point'];
    $credits += $r['credits'];
    $marks   += $r['total_marks'];
    $max     += MAX_TOTAL;
    if ($r['total_marks'] >= PASS_MARK) $passed++; else $failed++;
}
$cgpa       = $credits ? round($points / $credits, 2) : 0;
$overallPct = $max ? round($marks / $max * 100, 2) : 0;
$remark     = performanceRemark($overallPct);

/* how many semesters have been published */
$semCount = $pdo->prepare("SELECT COUNT(DISTINCT semester) FROM results WHERE student_id=? AND status='Published'");
$semCount->execute([$sid]);
$semCount = (int)$semCount->fetchColumn();

$LAYOUT = 'student'; $ACTIVE = 'dashboard'; $PAGE_TITLE = 'Dashboard';
include 'includes/header.php';
?>

<div class="card">
  <div class="card-head">
    <div style="display:flex;align-items:center;gap:1rem">
      <div class="avatar" style="width:64px;height:64px;font-size:1.3rem"><?= e(initials($student['name'])) ?></div>
      <div>
        <h3 style="margin:0">Welcome back, <?= e($student['name']) ?></h3>
        <p class="muted" style="margin:.2rem 0 0">
          <?= e($student['student_id']) ?> &nbsp;&middot;&nbsp; <?= e($student['department']) ?>
          &nbsp;&middot;&nbsp; Year <?= (int)$student['year'] ?>, Semester <?= (int)$student['semester'] ?>
        </p>
      </div>
    </div>
    <span class="badge <?= $lastSem ? 'b-pass' : 'b-draft' ?>">
      <?= $lastSem ? 'Semester ' . $lastSem . ' result published' : 'No result published yet' ?>
    </span>
  </div>

  <div class="quick-links">
    <a class="btn btn-primary btn-sm" href="result.php">View result</a>
    <a class="btn btn-ghost btn-sm" href="semesters.php">Semester results</a>
    <a class="btn btn-ghost btn-sm" href="performance.php">Performance</a>
    <a class="btn btn-gold btn-sm" href="result.php?print=1">Download result</a>
    <a class="btn btn-ghost btn-sm" href="profile.php">Profile</a>
    <a class="btn btn-danger btn-sm" href="logout.php">Logout</a>
  </div>
</div>

<div class="cards">
  <div class="stat-card gold"><small>Current CGPA</small><b><?= number_format($cgpa, 2) ?></b>
    <span class="sub">out of 10.00</span></div>
  <div class="stat-card"><small>Overall percentage</small><b><?= number_format($overallPct, 2) ?>%</b>
    <span class="sub"><?= $semCount ?> semester<?= $semCount == 1 ? '' : 's' ?> published</span></div>
  <div class="stat-card"><small>Current semester</small><b><?= (int)$student['semester'] ?></b>
    <span class="sub">Year <?= (int)$student['year'] ?></span></div>
  <div class="stat-card pass"><small>Subjects passed</small><b><?= $passed ?></b>
    <span class="sub">across all semesters</span></div>
  <div class="stat-card fail"><small>Subjects failed</small><b><?= $failed ?></b>
    <span class="sub"><?= $failed ? 'Reappear required' : 'Clean record' ?></span></div>
</div>

<div class="remark <?= e($remark['class']) ?>" style="margin-bottom:1.4rem">
  <h3><?= e($remark['title']) ?></h3>
  <p style="margin:0"><?= e($remark['text']) ?></p>
</div>

<div class="card">
  <div class="card-head">
    <h3>Latest result<?= $lastSem ? ' — Semester ' . $lastSem : '' ?></h3>
    <?php if ($lastSem): ?><a class="btn btn-ghost btn-sm" href="result.php">Open full marksheet</a><?php endif; ?>
  </div>

  <?php if (!$rows): ?>
    <p class="empty">Nothing to show yet. Your result will appear here as soon as the examination cell publishes it.</p>
  <?php else: ?>
    <div class="table-wrap">
      <table class="data">
        <thead><tr><th>Code</th><th>Subject</th><th class="num">Internal</th><th class="num">External</th>
          <th class="num">Total</th><th>Grade</th><th>Result</th></tr></thead>
        <tbody>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td><?= e($r['subject_code']) ?></td>
            <td><?= e($r['subject_name']) ?></td>
            <td class="num"><?= (int)$r['internal_marks'] ?></td>
            <td class="num"><?= (int)$r['external_marks'] ?></td>
            <td class="num"><b><?= (int)$r['total_marks'] ?></b></td>
            <td><span class="<?= gradeClass($r['grade']) ?>"><?= e($r['grade']) ?></span></td>
            <td><span class="badge <?= $r['total_marks'] >= PASS_MARK ? 'b-pass' : 'b-fail' ?>">
              <?= $r['total_marks'] >= PASS_MARK ? 'PASS' : 'FAIL' ?></span></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="ms-summary" style="margin-top:1rem;border-radius:10px">
      <div><b><?= $summary['total'] ?>/<?= $summary['max'] ?></b><small>Total marks</small></div>
      <div><b><?= number_format($summary['percentage'], 2) ?>%</b><small>Percentage</small></div>
      <div><b><?= number_format($summary['sgpa'], 2) ?></b><small>SGPA</small></div>
      <div><b><?= number_format($cgpa, 2) ?></b><small>CGPA</small></div>
      <div><b style="color:<?= $summary['status'] === 'PASS' ? 'var(--pass)' : 'var(--fail)' ?>"><?= $summary['status'] ?></b><small>Status</small></div>
    </div>
  <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
