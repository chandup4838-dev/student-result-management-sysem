<?php
/* ============================================================
   EduResult - Student Result Management System
   includes/config.php
   Database connection + common helper functions
   ============================================================ */

/* ---------- 1. DATABASE SETTINGS (change only if needed) ---------- */
define('DB_HOST', 'localhost');
define('DB_NAME', 'eduresult');
define('DB_USER', 'root');
define('DB_PASS', '');          // XAMPP default MySQL password is empty

/* ---------- 2. COLLEGE / EXAM SETTINGS ---------- */
define('COLLEGE_NAME', 'Sri Vidya Institute of Technology');
define('COLLEGE_SUB',  'Approved by AICTE | Affiliated to State Technical University');
define('ACADEMIC_YEAR', '2025 - 2026');
define('MAX_INTERNAL', 25);      // maximum internal marks per subject
define('MAX_EXTERNAL', 75);      // maximum external marks per subject
define('MAX_TOTAL', MAX_INTERNAL + MAX_EXTERNAL);   // = 100
define('PASS_MARK', 40);         // minimum total marks to pass a subject

/* ---------- 3. CONNECT TO MYSQL USING PDO ---------- */
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false   // real prepared statements
        ]
    );
} catch (PDOException $ex) {
    die('<h3 style="font-family:sans-serif">Database connection failed.</h3>
         <p style="font-family:sans-serif">Start MySQL in XAMPP and import <b>database/eduresult.sql</b>.<br>
         Error: ' . htmlspecialchars($ex->getMessage()) . '</p>');
}

/* ---------- 4. SMALL HELPERS ---------- */

/* escape output (stops XSS) */
function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/* redirect and stop the script */
function redirect($url) {
    header("Location: $url");
    exit;
}

/* one-time flash message stored in the session */
function set_flash($type, $msg) {
    $_SESSION['flash'] = ['type' => $type, 'msg' => $msg];
}
function get_flash() {
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}

/* ---------- 5. GRADING SYSTEM (easy to modify) ---------- */
/*  90-100 -> O  -> 10
    80-89  -> A+ -> 9
    70-79  -> A  -> 8
    60-69  -> B+ -> 7
    50-59  -> B  -> 6
    40-49  -> C  -> 5
    < 40   -> F  -> 0                                        */
function calculateGrade($total) {
    if ($total >= 90) return ['grade' => 'O',  'point' => 10];
    if ($total >= 80) return ['grade' => 'A+', 'point' => 9];
    if ($total >= 70) return ['grade' => 'A',  'point' => 8];
    if ($total >= 60) return ['grade' => 'B+', 'point' => 7];
    if ($total >= 50) return ['grade' => 'B',  'point' => 6];
    if ($total >= PASS_MARK) return ['grade' => 'C', 'point' => 5];
    return ['grade' => 'F', 'point' => 0];
}

/* colour class used by the CSS for a grade badge */
function gradeClass($grade) {
    if ($grade === 'F')  return 'g-fail';
    if ($grade === 'O' || $grade === 'A+') return 'g-top';
    if ($grade === 'A'  || $grade === 'B+') return 'g-good';
    return 'g-avg';
}

/* rule based performance remark (NOT AI - simple if/else) */
function performanceRemark($percentage) {
    if ($percentage >= 85) return ['title' => 'Excellent Academic Performance',
        'text' => 'Outstanding work. Keep this consistency and aim for university rank.', 'class' => 'rm-excellent'];
    if ($percentage >= 70) return ['title' => 'Very Good Performance',
        'text' => 'You are well above average. A little more focus can push you into the top band.', 'class' => 'rm-verygood'];
    if ($percentage >= 50) return ['title' => 'Good — Keep Improving',
        'text' => 'A steady result. Work on your weakest subject to raise your SGPA.', 'class' => 'rm-good'];
    return ['title' => 'Needs Improvement',
        'text' => 'Please meet your mentor, revise the basics and attend remedial classes.', 'class' => 'rm-poor'];
}

/* ---------- 6. SGPA / CGPA CALCULATION ---------- */
/*
   SGPA = SUM(credit * grade_point) / SUM(credits)   for one semester
   CGPA = SUM(credit * grade_point) / SUM(credits)   for all semesters so far
   The values are stored in the `semesters` table so pages load fast.
*/
function recalculateStudent(PDO $pdo, $student_id) {

    /* every semester in which this student has marks */
    $st = $pdo->prepare("SELECT DISTINCT semester FROM results WHERE student_id = ? ORDER BY semester ASC");
    $st->execute([$student_id]);
    $semesters = $st->fetchAll(PDO::FETCH_COLUMN);

    /* remove old rows so the table never keeps deleted semesters */
    $pdo->prepare("DELETE FROM semesters WHERE student_id = ?")->execute([$student_id]);

    $runningPoints = 0;   // SUM(credit * grade_point) over all semesters
    $runningCredits = 0;  // SUM(credits)              over all semesters

    foreach ($semesters as $sem) {
        $q = $pdo->prepare(
            "SELECT r.total_marks, r.grade_point, s.credits
             FROM results r
             JOIN subjects s ON s.id = r.subject_id
             WHERE r.student_id = ? AND r.semester = ?"
        );
        $q->execute([$student_id, $sem]);
        $rows = $q->fetchAll();

        $points = 0; $credits = 0; $marks = 0; $max = 0;
        foreach ($rows as $r) {
            $points  += $r['credits'] * $r['grade_point'];
            $credits += $r['credits'];
            $marks   += $r['total_marks'];
            $max     += MAX_TOTAL;
        }

        $sgpa       = $credits ? $points / $credits : 0;
        $percentage = $max ? ($marks / $max) * 100 : 0;

        $runningPoints  += $points;
        $runningCredits += $credits;
        $cgpa = $runningCredits ? $runningPoints / $runningCredits : 0;

        $ins = $pdo->prepare(
            "INSERT INTO semesters (student_id, semester, sgpa, cgpa, percentage)
             VALUES (?,?,?,?,?)"
        );
        $ins->execute([$student_id, $sem, round($sgpa, 2), round($cgpa, 2), round($percentage, 2)]);
    }
}

/* highest semester number whose results are PUBLISHED (0 = nothing published) */
function lastPublishedSemester(PDO $pdo, $student_id) {
    $q = $pdo->prepare("SELECT MAX(semester) FROM results WHERE student_id = ? AND status = 'Published'");
    $q->execute([$student_id]);
    return (int)$q->fetchColumn();
}

/* does this semester have published results? */
function isSemesterPublished(PDO $pdo, $student_id, $semester) {
    $q = $pdo->prepare("SELECT COUNT(*) FROM results WHERE student_id = ? AND semester = ? AND status = 'Published'");
    $q->execute([$student_id, $semester]);
    return $q->fetchColumn() > 0;
}

/* all published subject rows of one semester */
function getResultRows(PDO $pdo, $student_id, $semester, $onlyPublished = true) {
    $sql = "SELECT r.*, s.subject_code, s.subject_name, s.credits
            FROM results r
            JOIN subjects s ON s.id = r.subject_id
            WHERE r.student_id = ? AND r.semester = ?";
    if ($onlyPublished) $sql .= " AND r.status = 'Published'";
    $sql .= " ORDER BY s.subject_code ASC";
    $q = $pdo->prepare($sql);
    $q->execute([$student_id, $semester]);
    return $q->fetchAll();
}

/* build a summary array (totals, sgpa, pass/fail) from result rows */
function summarise($rows) {
    $total = 0; $max = 0; $points = 0; $credits = 0; $passed = 0; $failed = 0;
    foreach ($rows as $r) {
        $total   += $r['total_marks'];
        $max     += MAX_TOTAL;
        $points  += $r['credits'] * $r['grade_point'];
        $credits += $r['credits'];
        if ($r['total_marks'] >= PASS_MARK) $passed++; else $failed++;
    }
    return [
        'subjects'   => count($rows),
        'total'      => $total,
        'max'        => $max,
        'percentage' => $max ? round($total / $max * 100, 2) : 0,
        'sgpa'       => $credits ? round($points / $credits, 2) : 0,
        'credits'    => $credits,
        'passed'     => $passed,
        'failed'     => $failed,
        'status'     => ($failed === 0 && count($rows) > 0) ? 'PASS' : 'FAIL'
    ];
}

/* initials used for the avatar circle */
function initials($name) {
    $parts = preg_split('/\s+/', trim($name));
    $out = '';
    foreach ($parts as $p) { if ($p !== '') $out .= strtoupper($p[0]); if (strlen($out) == 2) break; }
    return $out ?: 'ST';
}
