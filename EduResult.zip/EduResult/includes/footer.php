<?php /* includes/footer.php - closes whichever layout header.php opened */ ?>

<?php if (($LAYOUT ?? 'public') === 'public'): ?>
</main>
<footer class="site-footer" id="contact">
  <div class="container footer-grid">
    <div>
      <a class="brand" href="<?= $BASE ?? '' ?>index.php">
        <span class="brand-mark">E</span>
        <span class="brand-text">Edu<b>Result</b></span>
      </a>
      <p class="muted">Your Results. Your Progress. Your Future.</p>
      <p class="muted tiny"><?= e(COLLEGE_NAME) ?></p>
    </div>
    <div>
      <h4>Quick Links</h4>
      <a href="<?= $BASE ?? '' ?>index.php#about">About</a>
      <a href="<?= $BASE ?? '' ?>index.php#features">Features</a>
      <a href="<?= $BASE ?? '' ?>search-result.php">Check Result</a>
      <a href="<?= $BASE ?? '' ?>login.php">Student Login</a>
      <a href="<?= $BASE ?? '' ?>admin/login.php">Admin Login</a>
    </div>
    <div>
      <h4>Contact</h4>
      <p class="muted">Examination Cell, Block A</p>
      <p class="muted">exam@eduresult.edu.in</p>
      <p class="muted">+91 98765 43210</p>
      <p class="muted">Mon - Sat, 9:30 AM to 5:00 PM</p>
    </div>
    <div>
      <h4>Academic Year</h4>
      <p class="muted"><?= e(ACADEMIC_YEAR) ?></p>
      <p class="muted">Results are published only after approval by the Controller of Examinations.</p>
    </div>
  </div>
  <div class="footer-bottom">
    &copy; <?= date('Y') ?> EduResult - Student Result Management System. Academic project.
  </div>
</footer>
<?php else: ?>
    </div><!-- /.page -->
  </div><!-- /.content -->
</div><!-- /.shell -->
<?php endif; ?>

<script src="<?= $BASE ?? '' ?>js/script.js"></script>
</body>
</html>
