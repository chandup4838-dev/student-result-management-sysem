<?php
/* ============================================================
   includes/header.php
   One header for three layouts:
     $LAYOUT = 'public'  -> top navigation bar (index, login, search)
     $LAYOUT = 'student' -> sidebar + topbar for the student area
     $LAYOUT = 'admin'   -> sidebar + topbar for the admin area
   Set $PAGE_TITLE and $ACTIVE before including this file.
   ============================================================ */

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/config.php';

$LAYOUT     = $LAYOUT     ?? 'public';
$PAGE_TITLE = $PAGE_TITLE ?? 'EduResult';
$ACTIVE     = $ACTIVE     ?? '';
$BASE       = $BASE ?? (($LAYOUT === 'admin') ? '../' : '');  // admin pages live one folder deeper
$flash      = get_flash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($PAGE_TITLE) ?> | EduResult</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,400;8..60,600;8..60,700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= $BASE ?>css/style.css">
</head>
<body class="layout-<?= e($LAYOUT) ?>">

<?php if ($LAYOUT === 'public'): ?>
<!-- ================= PUBLIC TOP NAVBAR ================= -->
<header class="navbar">
  <div class="container nav-inner">
    <a class="brand" href="<?= $BASE ?>index.php">
      <span class="brand-mark">E</span>
      <span class="brand-text">Edu<b>Result</b></span>
    </a>
    <input type="checkbox" id="navToggle" class="nav-toggle">
    <label for="navToggle" class="nav-burger">&#9776;</label>
    <nav class="nav-links">
      <a href="<?= $BASE ?>index.php">Home</a>
      <a href="<?= $BASE ?>index.php#about">About</a>
      <a href="<?= $BASE ?>index.php#features">Features</a>
      <a href="<?= $BASE ?>index.php#how">How It Works</a>
      <a href="<?= $BASE ?>index.php#contact">Contact</a>
      <a class="btn btn-ghost btn-sm" href="<?= $BASE ?>search-result.php">Check Result</a>
      <a class="btn btn-primary btn-sm" href="<?= $BASE ?>login.php">Login</a>
    </nav>
  </div>
</header>
<main class="public-main">
<?php endif; ?>

<?php if ($LAYOUT === 'student' || $LAYOUT === 'admin'):
    $isAdminLayout = ($LAYOUT === 'admin');
    $menu = $isAdminLayout ? [
        ['dashboard.php', 'Dashboard',          'dashboard', '▤'],
        ['students.php',  'Student Management', 'students',  '👤'],
        ['subjects.php',  'Subject Management', 'subjects',  '📚'],
        ['results.php',   'Result Management',  'results',   '📝'],
        ['semesters.php', 'SGPA / CGPA',        'semesters', '📈'],
        ['logout.php',    'Logout',             'logout',    '⎋'],
    ] : [
        ['dashboard.php',   'Dashboard',        'dashboard',   '▤'],
        ['result.php',      'View Result',      'result',      '📄'],
        ['semesters.php',   'Academic Journey', 'semesters',   '🎓'],
        ['performance.php', 'Performance',      'performance', '📊'],
        ['profile.php',     'Profile',          'profile',     '👤'],
        ['logout.php',      'Logout',           'logout',      '⎋'],
    ];
    $userName = $isAdminLayout ? ($_SESSION['admin_user'] ?? 'Admin') : ($_SESSION['student_name'] ?? 'Student');
    $userSub  = $isAdminLayout ? 'Administrator' : ($_SESSION['student_id'] ?? '');
?>
<!-- ================= DASHBOARD SHELL ================= -->
<div class="shell">
  <input type="checkbox" id="sideToggle" class="side-toggle">
  <aside class="sidebar">
    <a class="brand sidebar-brand" href="<?= $BASE ?>index.php">
      <span class="brand-mark">E</span>
      <span class="brand-text">Edu<b>Result</b></span>
    </a>
    <p class="sidebar-label"><?= $isAdminLayout ? 'Admin Panel' : 'Student Panel' ?></p>
    <nav class="side-menu">
      <?php foreach ($menu as $m): ?>
        <a href="<?= e($m[0]) ?>" class="<?= $ACTIVE === $m[2] ? 'active' : '' ?>">
          <span class="ic"><?= $m[3] ?></span><?= e($m[1]) ?>
        </a>
      <?php endforeach; ?>
    </nav>
    <div class="sidebar-foot">
      <p>EduResult v1.0</p>
      <p class="tiny">Your Results. Your Progress.<br>Your Future.</p>
    </div>
  </aside>

  <div class="content">
    <header class="topbar">
      <label for="sideToggle" class="burger">&#9776;</label>
      <h1 class="page-title"><?= e($PAGE_TITLE) ?></h1>
      <div class="topbar-user">
        <div class="avatar"><?= e(initials($userName)) ?></div>
        <div class="tu-text">
          <strong><?= e($userName) ?></strong>
          <span><?= e($userSub) ?></span>
        </div>
      </div>
    </header>
    <div class="page">
<?php endif; ?>

<?php if ($flash): ?>
  <div class="alert alert-<?= e($flash['type']) ?>"><?= e($flash['msg']) ?></div>
<?php endif; ?>
