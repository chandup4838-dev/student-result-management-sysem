<?php
/* ============================================================
   includes/auth.php  -  PHP session handling and page guards
   Include this file at the TOP of every protected page.
   ============================================================ */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/config.php';

/* is a student logged in? */
function isStudent() {
    return isset($_SESSION['student_id']);
}

/* is an admin logged in? */
function isAdmin() {
    return isset($_SESSION['admin_id']);
}

/* block the page if no student session exists */
function requireStudent() {
    if (!isStudent()) {
        set_flash('error', 'Please login to continue.');
        redirect('login.php');
    }
}

/* block the page if no admin session exists */
function requireAdmin() {
    if (!isAdmin()) {
        set_flash('error', 'Admin login required.');
        redirect('login.php');
    }
}

/* full row of the logged in student */
function currentStudent(PDO $pdo) {
    static $student = null;
    if ($student === null && isStudent()) {
        $q = $pdo->prepare("SELECT * FROM users WHERE student_id = ?");
        $q->execute([$_SESSION['student_id']]);
        $student = $q->fetch();
    }
    return $student;
}
