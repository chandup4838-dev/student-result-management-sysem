<?php
/* performance.php - rule based performance analysis (no AI) */
require_once 'includes/auth.php';
requireStudent();

$student = currentStudent($pdo);
$sid = $student['student_id'];

$q = $pdo->prepare("SELECT DISTINCT semester FROM results WHERE student_id=? AND status='Published' ORDER BY semester");
$q->execute([$sid]);
$openSemesters = array_map('intval', $q->fetchAll(PDO::FETCH_COLUMN));

$semester = isset($_GET['sem']) ? (int)$_GET['sem'] : (int)(end($openSemesters) ?: 0);
if ($openSemesters && !in_array($semester, $openSemesters, true)) $semester = (int)end($openSemesters);

$rows    = $semester ? getResultRows($pdo, $sid, $semester) : [];
$summary = summarise($rows);

/* highest / lowest / average - plain PHP, no library */
$highest = null; $lowest = null; $sum = 0;
foreach ($rows as $r) {
    $sum += $r['total_marks'];
    if ($highest === null || $r['total_marks'] > $highest['total_marks']) $highest = $r;
    if ($lowest  === null || $r['total_marks'] < $lowest['total_marks'])  $lowest  = $r;
}
$average = $rows ? round($sum / count($rows), 2) : 0;
$remark  = performanceRemark($summary['percentage']);

/* trend data for the SGPA / CGPA chart */
$t = $pdo->prepare(
    "SELECT sm.semester, sm.sgpa, sm.cgpa FROM semesters sm
     WHERE sm.student_id = ?
       AND EXISTS (SELECT 1 FROM results r WHERE r.student_id = sm.student_id
                   AND r.semester = sm.semester AND r.status = 'Published')
     ORDER BY sm.semester"
);
$t->execute([$sid]);
$trend = [];
foreach ($t->fetchAll() as $row) {
    $trend[] = ['sem' => (int)$row['semester'], 'sgpa' => (float)$row['sgpa'], 'cgpa' => (float)$row['cgpa']];
}

$LAYOUT = 'student'; $ACTIVE = 'performance'; $PAGE_TITLE = 'Performance Analysis';
include 'includes/header.php';
?>

<?php if (!$rows): ?>
  <div class="card"><p class="empty">Performance analysis appears once a result has been published.</p></div>
<?php else: ?>

<div class="card">
  <div class="card-head">
    <h3>Semester <?= $semester ?> analysis</h3>
    <form method="get">
      <select name="sem" onchange="this.form.submit()" style="width:auto">
        <?php foreach ($openSemesters as $s): ?>
          <option value="<?= $s ?>" <?= $s === $semester ? 'selected' : '' ?>>Semester <?= $s ?></option>
        <?php endforeach; ?>
      </select>
    </form>
  </div>

  <div class="remark <?= e($remark['class']) ?>">
    <h3><?= e($remark['title']) ?></h3>
    <p style="margin:0"><?= e($remark['text']) ?>
       You scored <b><?= number_format($summary['percentage'], 2) ?>%</b> with an SGPA of
       <b><?= number_format($summary['sgpa'], 2) ?></b> this semester.</p>
  </div>
</div>

<div class="cards">
  <div class="stat-card gold"><small>Highest scoring subject</small>
    <b><?= (int)$highest['total_marks'] ?></b><span class="sub"><?= e($highest['subject_name']) ?></span></div>
  <div class="stat-card"><small>Lowest scoring subject</small>
    <b><?= (int)$lowest['total_marks'] ?></b><span class="sub"><?= e($lowest['subject_name']) ?></span></div>
  <div class="stat-card"><small>Average marks</small>
    <b><?= number_format($average, 2) ?></b><span class="sub">per subject, out of <?= MAX_TOTAL ?></span></div>
  <div class="stat-card pass"><small>Subjects passed</small>
    <b><?= $summary['passed'] ?></b><span class="sub">of <?= $summary['subjects'] ?> subjects</span></div>
  <div class="stat-card fail"><small>Subjects failed</small>
    <b><?= $summary['failed'] ?></b><span class="sub"><?= $summary['failed'] ? 'Reappear required' : 'All clear' ?></span></div>
</div>

<div class="card">
  <div class="card-head"><h3>Subject performance</h3>
    <span class="tiny muted">Marks out of <?= MAX_TOTAL ?></span></div>
  <?php foreach ($rows as $r):
      $pct = $r['total_marks'];
      $cls = '';
      if ($r['total_marks'] < PASS_MARK) $cls = 'fail';
      elseif ($highest && $r['id'] == $highest['id']) $cls = 'top';
      elseif ($lowest && $r['id'] == $lowest['id']) $cls = 'low';
  ?>
    <div class="bar-row">
      <span title="<?= e($r['subject_name']) ?>"><?= e($r['subject_name']) ?></span>
      <span class="bar-track"><span class="bar-fill <?= $cls ?>" data-width="<?= (int)$pct ?>"></span></span>
      <span class="bar-val"><?= (int)$pct ?>%</span>
    </div>
  <?php endforeach; ?>
  <p class="tiny muted" style="margin-top:1rem">
    Gold marks your best subject, grey your weakest, red an uncleared subject.
  </p>
</div>

<?php if (count($trend) > 1): ?>
<div class="card">
  <div class="card-head"><h3>SGPA and CGPA trend</h3>
    <span class="tiny muted">Drawn in the browser from your own records</span></div>
  <div class="trend" id="cgpaTrend" data-points='<?= json_encode($trend) ?>'></div>
</div>
<?php endif; ?>

<div class="card">
  <h3>How this page is calculated</h3>
  <ul class="muted" style="margin:0;padding-left:1.1rem">
    <li>Each bar is simply the total marks of that subject out of <?= MAX_TOTAL ?>.</li>
    <li>Highest, lowest and average are found by looping over the result rows in PHP.</li>
    <li>The remark comes from an if/else ladder on the semester percentage — not from AI.</li>
    <li>The trend chart is drawn as an SVG by <code>js/script.js</code> using the stored SGPA and CGPA.</li>
  </ul>
</div>

<?php endif; ?>
<?php include 'includes/footer.php'; ?>
