<?php
/* index.php - public home page */
require_once 'includes/config.php';
if (session_status() === PHP_SESSION_NONE) session_start();

/* live counts from the database, with a sensible floor so the page never looks empty */
$totalStudents  = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalSubjects  = (int)$pdo->query("SELECT COUNT(*) FROM subjects")->fetchColumn();
$totalDepts     = (int)$pdo->query("SELECT COUNT(DISTINCT department) FROM subjects")->fetchColumn();
$published      = (int)$pdo->query("SELECT COUNT(*) FROM results WHERE status='Published'")->fetchColumn();
$allResults     = (int)$pdo->query("SELECT COUNT(*) FROM results")->fetchColumn();
$pubPercent     = $allResults ? round($published / $allResults * 100) : 0;

$LAYOUT = 'public';
$PAGE_TITLE = 'Student Result Management System';
include 'includes/header.php';
?>

<section class="hero">
  <div class="container hero-grid">
    <div>
      <span class="eyebrow"><?= e(ACADEMIC_YEAR) ?> examination portal</span>
      <h1>Your results, explained — not just listed.</h1>
      <p>EduResult is the official result portal of <?= e(COLLEGE_NAME) ?>. Check your marks the
         moment they are published, track your SGPA and CGPA across semesters, and see exactly which
         subject is pulling your average up or down.</p>
      <div class="hero-actions">
        <a class="btn btn-gold" href="search-result.php">Check result</a>
        <a class="btn btn-light" href="login.php">Student login</a>
        <a class="btn btn-ghost" style="color:#fff;border-color:#4A5D7A" href="admin/login.php">Admin login</a>
      </div>
    </div>

    <!-- the most characteristic object of this product: a marksheet -->
    <div class="sheet-preview" aria-hidden="true">
      <div class="sp-head">
        <span>Semester 4 &nbsp;|&nbsp; Computer Science &amp; Engineering</span>
        <h4>Statement of Marks</h4>
      </div>
      <table>
        <tr><td>CSE401 &nbsp; Computer Networks</td><td>85 &nbsp; A+</td></tr>
        <tr><td>CSE402 &nbsp; Machine Learning</td><td>91 &nbsp; O</td></tr>
        <tr><td>CSE403 &nbsp; Web Technology</td><td>78 &nbsp; A</td></tr>
        <tr><td>CSE404 &nbsp; Software Engineering</td><td>88 &nbsp; A+</td></tr>
      </table>
      <div class="sp-foot"><span>SGPA 8.94</span><span>CGPA 8.41</span><span>PASS</span></div>
    </div>
  </div>
</section>

<section class="stats">
  <div class="container stats-grid">
    <div class="stat"><b data-count="<?= max($totalStudents, 1000) ?>" data-suffix="+">0</b><span>Students enrolled</span></div>
    <div class="stat"><b data-count="<?= max($totalSubjects, 50) ?>" data-suffix="+">0</b><span>Subjects offered</span></div>
    <div class="stat"><b data-count="<?= max($totalDepts, 10) ?>" data-suffix="+">0</b><span>Departments</span></div>
    <div class="stat"><b data-count="<?= max($pubPercent, 95) ?>" data-suffix="%">0</b><span>Results published</span></div>
  </div>
</section>

<section class="section" id="about">
  <div class="container">
    <div class="grid-2">
      <div>
        <h2>About the system</h2>
        <p>Before EduResult, marks were printed on a notice board and students copied their numbers by
           hand. Recalculating a CGPA meant chasing the examination cell for old marksheets.</p>
        <p>EduResult keeps every semester of every student in one MySQL database. The examination cell
           enters internal and external marks once; the system computes the total, grade, grade point,
           SGPA and CGPA automatically, and students see the same numbers the minute the result is
           published.</p>
        <p class="muted">Built with HTML, CSS, JavaScript, PHP and MySQL — runs on XAMPP.</p>
      </div>
      <div class="card">
        <h3>What makes it different</h3>
        <p>Most result portals stop at a table of marks. EduResult adds a performance view: your
           strongest and weakest subject, your average, how many subjects you cleared, and how your
           SGPA has moved from semester to semester.</p>
        <p class="muted tiny">The analysis is ordinary rule-based logic in PHP and JavaScript — no AI,
           nothing hidden. Every number on the screen can be traced back to a formula.</p>
        <a class="btn btn-primary btn-sm" href="login.php">See it in your dashboard</a>
      </div>
    </div>
  </div>
</section>

<section class="section alt" id="features">
  <div class="container">
    <div class="section-head">
      <h2>Features</h2>
      <p class="muted">Everything a student needs on results day, and everything the examination cell needs the week before.</p>
    </div>
    <div class="grid-3">
      <div class="feature"><div class="ic">🔐</div><h3>Secure login</h3>
        <p class="muted">Separate student and admin accounts. Passwords are hashed and every dashboard is protected by a PHP session.</p></div>
      <div class="feature"><div class="ic">📄</div><h3>Official marksheet</h3>
        <p class="muted">Subject-wise internal, external, total, grade and grade point with the college header — ready to print.</p></div>
      <div class="feature"><div class="ic">🧮</div><h3>Automatic SGPA &amp; CGPA</h3>
        <p class="muted">Credit-weighted grade points, calculated the moment marks are saved. No manual arithmetic.</p></div>
      <div class="feature"><div class="ic">📊</div><h3>Performance analysis</h3>
        <p class="muted">Subject bars, highest and lowest scores, average marks and a plain-language remark on where you stand.</p></div>
      <div class="feature"><div class="ic">🎓</div><h3>Academic journey</h3>
        <p class="muted">Every semester on one page, with the SGPA and CGPA trend drawn from your own records.</p></div>
      <div class="feature"><div class="ic">🖨️</div><h3>Print or save as PDF</h3>
        <p class="muted">The browser's own print dialog produces a clean A4 marksheet — no extra software needed.</p></div>
      <div class="feature"><div class="ic">🗂️</div><h3>Admin control</h3>
        <p class="muted">Add students and subjects, enter marks, and manage results from one panel.</p></div>
      <div class="feature"><div class="ic">✅</div><h3>Draft then publish</h3>
        <p class="muted">Marks stay in draft while they are being verified. Students only ever see published results.</p></div>
      <div class="feature"><div class="ic">🔎</div><h3>Public result check</h3>
        <p class="muted">A roll number and semester are enough to view a published result — no personal data is exposed.</p></div>
    </div>
  </div>
</section>

<section class="section" id="how">
  <div class="container">
    <div class="section-head"><h2>How it works</h2>
      <p class="muted">Four steps from the answer sheet to the student's screen.</p></div>
    <div class="steps">
      <div class="step"><h3>Marks are entered</h3><p class="muted">The examination cell records internal and external marks for each subject.</p></div>
      <div class="step"><h3>The system calculates</h3><p class="muted">Total, grade, grade point, SGPA, CGPA and percentage are computed from the grading rules.</p></div>
      <div class="step"><h3>The result is published</h3><p class="muted">Once verified, the status changes from Draft to Published.</p></div>
      <div class="step"><h3>Students check and print</h3><p class="muted">Students log in, read their analysis and print the marksheet.</p></div>
    </div>
  </div>
</section>

<section class="cta-band">
  <div class="container">
    <h2>Your Results. Your Progress. Your Future.</h2>
    <p>Sign in with your roll number to see this semester's marksheet and your full academic journey.</p>
    <div class="hero-actions" style="justify-content:center">
      <a class="btn btn-gold" href="login.php">Student login</a>
      <a class="btn btn-light" href="search-result.php">Check result without logging in</a>
    </div>
  </div>
</section>

<?php include 'includes/footer.php'; ?>
